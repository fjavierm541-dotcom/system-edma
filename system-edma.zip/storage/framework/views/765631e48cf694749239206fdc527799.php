<?php if(session('success')): ?>
    <div
        class="alert alert-success portal-alert alert-dismissible fade show"
        role="alert"
    >
        <i class="bi bi-check-circle-fill"></i>

        <div>
            <strong>Proceso completado</strong>
            <span><?php echo e(session('success')); ?></span>
        </div>

        <button
            type="button"
            class="btn-close"
            data-bs-dismiss="alert"
            aria-label="Cerrar"
        ></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div
        class="alert alert-danger portal-alert alert-dismissible fade show"
        role="alert"
    >
        <i class="bi bi-exclamation-octagon-fill"></i>

        <div>
            <strong>No fue posible completar el proceso</strong>
            <span><?php echo e(session('error')); ?></span>
        </div>

        <button
            type="button"
            class="btn-close"
            data-bs-dismiss="alert"
            aria-label="Cerrar"
        ></button>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div
        class="alert alert-danger portal-alert alert-dismissible fade show"
        role="alert"
    >
        <i class="bi bi-exclamation-triangle-fill"></i>

        <div>
            <strong>Revise la información ingresada</strong>

            <ul class="mb-0 mt-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <button
            type="button"
            class="btn-close"
            data-bs-dismiss="alert"
            aria-label="Cerrar"
        ></button>
    </div>
<?php endif; ?><?php /**PATH C:\laragon\www\system-edma\resources\views/components/portal/alerts.blade.php ENDPATH**/ ?>