

<?php $__env->startSection('title', 'Editar programa | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Editar programa'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión académica
            </span>

            <h1>Editar programa académico</h1>

            <p>
                Actualice la información de
                <?php echo e($programa->nombre); ?>.
            </p>
        </div>

        <div class="portal-page-actions">

            <a
                href="<?php echo e(route(
                    'portal.programas.show',
                    $programa
                )); ?>"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver al programa
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form
        action="<?php echo e(route(
            'portal.programas.update',
            $programa
        )); ?>"
        method="POST"
        novalidate
    >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <?php echo $__env->make('portal.programas.partials._form', [
            'programa' => $programa,
            'modoEdicion' => true,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/programas/edit.blade.php ENDPATH**/ ?>