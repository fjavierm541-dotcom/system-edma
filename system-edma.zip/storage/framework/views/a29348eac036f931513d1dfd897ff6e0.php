

<?php $__env->startSection('title', $docente->codigo_docente . ' | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Perfil docente'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión académica
            </span>

            <h1>
                <?php echo e($docente->empleado->persona->nombre_completo); ?>

            </h1>

            <p>
                Consulte la información docente, laboral y académica
                asociada al perfil.
            </p>
        </div>

        <div class="portal-page-actions portal-page-actions-group">

            <a
                href="<?php echo e(route('portal.docentes.index')); ?>"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver
            </a>

            <a
                href="<?php echo e(route('portal.docentes.edit', $docente)); ?>"
                class="btn portal-btn-primary"
            >
                <i class="bi bi-pencil-square"></i>
                Editar perfil
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
        $empleado = $docente->empleado;
        $persona = $empleado->persona;

        $numeroWhatsapp = null;

        if (
            $persona->telefono_movil &&
            $persona->telefono_movil_whatsapp
        ) {
            $numeroWhatsapp = preg_replace(
                '/\D+/',
                '',
                $persona->telefono_movil
            );

            if (
                strlen($numeroWhatsapp) === 8 &&
                $persona->paisResidencia?->codigo_iso2 === 'HN'
            ) {
                $numeroWhatsapp = '504' . $numeroWhatsapp;
            }
        }
    ?>

    <div class="row g-4">

        
        <div class="col-12 col-xl-4 col-xxl-3">

            <section class="portal-card portal-profile-card">

                <div class="portal-profile-cover"></div>

                <div class="portal-profile-content">

                    <div class="portal-profile-photo">

                        <?php if($persona->foto_perfil): ?>

                            <img
                                src="<?php echo e(asset(
                                    'storage/' . $persona->foto_perfil
                                )); ?>"
                                alt="Fotografía de <?php echo e($persona->nombre_completo); ?>"
                            >

                        <?php else: ?>

                            <span>
                                <?php echo e($persona->iniciales ?: 'DO'); ?>

                            </span>

                        <?php endif; ?>

                    </div>

                    <h2>
                        <?php echo e($persona->nombre_completo); ?>

                    </h2>

                    <span class="portal-teacher-code mt-2">
                        <?php echo e($docente->codigo_docente); ?>

                    </span>

                    <div class="mt-3">

                        <?php if($docente->estado === 'activo'): ?>

                            <span class="portal-status-badge portal-status-active">
                                <span></span>
                                Docente activo
                            </span>

                        <?php else: ?>

                            <span class="portal-status-badge portal-status-inactive">
                                <span></span>
                                Docente inactivo
                            </span>

                        <?php endif; ?>

                    </div>

                </div>

                <div class="portal-profile-summary">

                    <div>
                        <span>Inicio de docencia</span>

                        <strong>
                            <?php echo e($docente->fecha_inicio_docencia
                                ? $docente->fecha_inicio_docencia
                                    ->translatedFormat('d M Y')
                                : 'No registrada'); ?>

                        </strong>
                    </div>

                    <div>
                        <span>Especialidad</span>

                        <strong>
                            <?php echo e($docente->especialidad
                                ?: 'No especificada'); ?>

                        </strong>
                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-profile-actions-card">

                <div class="portal-card-header">

                    <div>
                        <h2>Acciones</h2>
                        <p>Operaciones disponibles.</p>
                    </div>

                </div>

                <div class="portal-profile-actions">

                    <a
                        href="<?php echo e(route(
                            'portal.docentes.edit',
                            $docente
                        )); ?>"
                        class="portal-profile-action"
                    >
                        <span>
                            <i class="bi bi-pencil-square"></i>
                        </span>

                        <div>
                            <strong>Editar perfil docente</strong>
                            <small>Actualizar información académica</small>
                        </div>

                        <i class="bi bi-chevron-right"></i>
                    </a>

                    <a
                        href="<?php echo e(route(
                            'portal.empleados.show',
                            $empleado
                        )); ?>"
                        class="portal-profile-action"
                    >
                        <span>
                            <i class="bi bi-briefcase"></i>
                        </span>

                        <div>
                            <strong>Ver expediente laboral</strong>

                            <small>
                                <?php echo e($empleado->codigo_empleado); ?>

                            </small>
                        </div>

                        <i class="bi bi-chevron-right"></i>
                    </a>

                    <a
                        href="<?php echo e(route(
                            'portal.personas.show',
                            $persona
                        )); ?>"
                        class="portal-profile-action"
                    >
                        <span>
                            <i class="bi bi-person-vcard"></i>
                        </span>

                        <div>
                            <strong>Ver datos personales</strong>
                            <small>Consultar expediente general</small>
                        </div>

                        <i class="bi bi-chevron-right"></i>
                    </a>

                    <?php if($numeroWhatsapp): ?>

                        <a
                            href="https://wa.me/<?php echo e($numeroWhatsapp); ?>"
                            target="_blank"
                            rel="noopener noreferrer"
                            class="portal-profile-action"
                        >
                            <span class="portal-profile-action-success">
                                <i class="bi bi-whatsapp"></i>
                            </span>

                            <div>
                                <strong>Contactar por WhatsApp</strong>
                                <small><?php echo e($persona->telefono_movil); ?></small>
                            </div>

                            <i class="bi bi-box-arrow-up-right"></i>
                        </a>

                    <?php endif; ?>

                    <button
                        type="button"
                        class="portal-profile-action portal-profile-action-button"
                        data-bs-toggle="modal"
                        data-bs-target="#changeTeacherStatusModal"
                    >
                        <span>
                            <i class="bi bi-person-gear"></i>
                        </span>

                        <div>
                            <strong>
                                <?php echo e($docente->estado === 'activo'
                                    ? 'Desactivar docente'
                                    : 'Activar docente'); ?>

                            </strong>

                            <small>
                                <?php echo e($docente->estado === 'activo'
                                    ? 'Conservará su historial docente'
                                    : 'Habilitar nuevamente el perfil'); ?>

                            </small>
                        </div>

                        <i class="bi bi-chevron-right"></i>
                    </button>

                </div>

            </section>

        </div>

        
        <div class="col-12 col-xl-8 col-xxl-9">

            
            <section class="portal-card portal-detail-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-easel"></i>
                    </div>

                    <div>
                        <h2>Información docente</h2>

                        <p>
                            Información propia de su función académica.
                        </p>
                    </div>

                </div>

                <div class="portal-detail-grid">

                    <div class="portal-detail-item">

                        <span>Código docente</span>

                        <strong>
                            <?php echo e($docente->codigo_docente); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Especialidad</span>

                        <strong>
                            <?php echo e($docente->especialidad
                                ?: 'No especificada'); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Fecha de inicio de docencia</span>

                        <strong>
                            <?php echo e($docente->fecha_inicio_docencia
                                ? $docente->fecha_inicio_docencia
                                    ->translatedFormat(
                                        'd \d\e F \d\e Y'
                                    )
                                : 'No registrada'); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Estado docente</span>

                        <strong>
                            <?php echo e(str($docente->estado)->title()); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item portal-detail-item-full">

                        <span>Observaciones</span>

                        <strong>
                            <?php echo e($docente->observaciones
                                ?: 'Sin observaciones registradas'); ?>

                        </strong>

                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-detail-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-briefcase"></i>
                    </div>

                    <div>
                        <h2>Información laboral</h2>

                        <p>
                            Datos provenientes del expediente de empleado.
                        </p>
                    </div>

                </div>

                <div class="portal-detail-grid">

                    <div class="portal-detail-item">

                        <span>Código de empleado</span>

                        <strong>
                            <?php echo e($empleado->codigo_empleado); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Fecha de ingreso</span>

                        <strong>
                            <?php echo e($empleado->fecha_ingreso
                                ? $empleado->fecha_ingreso
                                    ->translatedFormat(
                                        'd \d\e F \d\e Y'
                                    )
                                : 'No registrada'); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Estado laboral</span>

                        <strong>
                            <?php echo e(str($empleado->estado)->title()); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Institución laboral actual</span>

                        <strong>
                            <?php echo e($empleado->institucion_laboral_actual
                                ?: 'No especificada'); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item portal-detail-item-full">

                        <span>Horario laboral actual</span>

                        <strong>
                            <?php echo e($empleado->horario_laboral_actual
                                ?: 'No especificado'); ?>

                        </strong>

                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-detail-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-person-vcard"></i>
                    </div>

                    <div>
                        <h2>Datos personales</h2>

                        <p>
                            Información proveniente del módulo Personas.
                        </p>
                    </div>

                </div>

                <div class="portal-detail-grid">

                    <div class="portal-detail-item">

                        <span>Nombre completo</span>

                        <strong>
                            <?php echo e($persona->nombre_completo); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Documento</span>

                        <strong>
                            <?php echo e($persona->numero_documento
                                ?: 'No registrado'); ?>

                        </strong>

                        <?php if($persona->tipo_documento): ?>

                            <small>
                                <?php echo e(str($persona->tipo_documento)
                                    ->replace('_', ' ')
                                    ->title()); ?>

                            </small>

                        <?php endif; ?>

                    </div>

                    <div class="portal-detail-item">

                        <span>Fecha de nacimiento</span>

                        <strong>
                            <?php echo e($persona->fecha_nacimiento
                                ? $persona->fecha_nacimiento
                                    ->translatedFormat(
                                        'd \d\e F \d\e Y'
                                    )
                                : 'No especificada'); ?>

                        </strong>

                        <?php if($persona->fecha_nacimiento): ?>

                            <small>
                                <?php echo e($persona->fecha_nacimiento->age); ?> años
                            </small>

                        <?php endif; ?>

                    </div>

                    <div class="portal-detail-item">

                        <span>Correo personal</span>

                        <?php if($persona->correo_personal): ?>

                            <a
                                href="mailto:<?php echo e($persona->correo_personal); ?>"
                            >
                                <?php echo e($persona->correo_personal); ?>

                            </a>

                        <?php else: ?>

                            <strong>No registrado</strong>

                        <?php endif; ?>

                    </div>

                    <div class="portal-detail-item">

                        <span>Teléfono móvil</span>

                        <strong>
                            <?php echo e($persona->telefono_movil
                                ?: 'No registrado'); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>País de residencia</span>

                        <strong>
                            <?php echo e($persona->paisResidencia?->nombre
                                ?: 'No especificado'); ?>

                        </strong>

                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-detail-card">

                <div class="portal-form-section-header portal-section-header-actions">

                    <div class="d-flex align-items-center gap-3">

                        <div class="portal-form-section-icon">
                            <i class="bi bi-mortarboard"></i>
                        </div>

                        <div>
                            <h2>Formación académica</h2>

                            <p>
                                Estudios y títulos registrados
                                en el expediente de la persona.
                            </p>
                        </div>

                    </div>

                    <span class="portal-results-count">
                        <?php echo e($persona->formacionesAcademicas->count()); ?>

                    </span>

                </div>

                <?php if($persona->formacionesAcademicas->isNotEmpty()): ?>

                    <div class="portal-academic-list">

                        <?php $__currentLoopData = $persona->formacionesAcademicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <article
                                class="portal-academic-item
                                    <?php echo e($formacion->estado !== 'activo'
                                        ? 'portal-academic-item-inactive'
                                        : ''); ?>"
                            >

                                <div class="portal-academic-icon">
                                    <i class="bi bi-mortarboard"></i>
                                </div>

                                <div class="portal-academic-info">

                                    <div class="d-flex align-items-center flex-wrap gap-2">

                                        <strong>
                                            <?php echo e($formacion->titulo_obtenido
                                                ?: $formacion->nivel_academico); ?>

                                        </strong>

                                        <?php if($formacion->es_principal): ?>

                                            <span class="portal-small-badge">
                                                Principal
                                            </span>

                                        <?php endif; ?>

                                        <?php if($formacion->estado !== 'activo'): ?>

                                            <span class="portal-status-badge portal-status-inactive">
                                                Inactiva
                                            </span>

                                        <?php endif; ?>

                                    </div>

                                    <span>
                                        <?php echo e($formacion->nivel_academico
                                            ?: 'Nivel no especificado'); ?>

                                    </span>

                                    <small>
                                        <?php echo e(collect([
                                            $formacion->institucion_educativa,
                                            $formacion->pais?->nombre,
                                            $formacion->anio_graduacion,
                                        ])->filter()->implode(' · ')); ?>

                                    </small>

                                </div>

                            </article>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php else: ?>

                    <div class="portal-empty-state portal-empty-state-documents">

                        <div class="portal-empty-icon">
                            <i class="bi bi-mortarboard"></i>
                        </div>

                        <h3>No hay formación académica registrada</h3>

                        <p>
                            La formación académica puede gestionarse
                            desde el expediente laboral del empleado.
                        </p>

                        <a
                            href="<?php echo e(route(
                                'portal.empleados.show',
                                $empleado
                            )); ?>"
                            class="btn portal-btn-secondary mt-3"
                        >
                            <i class="bi bi-briefcase"></i>
                            Ir al expediente laboral
                        </a>

                    </div>

                <?php endif; ?>

            </section>

            
            <section class="portal-card portal-detail-card mb-0">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-calendar3"></i>
                    </div>

                    <div>
                        <h2>Asignaciones académicas</h2>

                        <p>
                            Grupos y horarios asignados al docente.
                        </p>
                    </div>

                </div>

                <div class="portal-empty-state portal-empty-state-documents">

                    <div class="portal-empty-icon">
                        <i class="bi bi-hourglass-split"></i>
                    </div>

                    <h3>Asignaciones pendientes</h3>

                    <p>
                        Esta sección se habilitará cuando desarrollemos
                        los módulos de grupos, horarios y asignación docente.
                    </p>

                </div>

            </section>

        </div>

    </div>

    
    <div
        class="modal fade"
        id="changeTeacherStatusModal"
        tabindex="-1"
        aria-labelledby="changeTeacherStatusModalLabel"
        aria-hidden="true"
    >
        <div class="modal-dialog modal-dialog-centered">

            <div class="modal-content portal-modal">

                <form
                    action="<?php echo e(route(
                        'portal.docentes.cambiar-estado',
                        $docente
                    )); ?>"
                    method="POST"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <div class="modal-header">

                        <div>
                            <span class="portal-modal-eyebrow">
                                Confirmación
                            </span>

                            <h2
                                class="modal-title"
                                id="changeTeacherStatusModalLabel"
                            >
                                <?php echo e($docente->estado === 'activo'
                                    ? 'Desactivar docente'
                                    : 'Activar docente'); ?>

                            </h2>
                        </div>

                        <button
                            type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Cerrar"
                        ></button>

                    </div>

                    <div class="modal-body">

                        <div class="portal-modal-warning-icon">
                            <i class="bi bi-person-gear"></i>
                        </div>

                        <p class="mb-0">

                            <?php if($docente->estado === 'activo'): ?>

                                ¿Desea desactivar a

                                <strong>
                                    <?php echo e($persona->nombre_completo); ?>

                                </strong>

                                como docente? Su historial académico
                                permanecerá disponible.

                            <?php else: ?>

                                ¿Desea activar nuevamente a

                                <strong>
                                    <?php echo e($persona->nombre_completo); ?>

                                </strong>

                                como docente?

                            <?php endif; ?>

                        </p>

                    </div>

                    <div class="modal-footer">

                        <button
                            type="button"
                            class="btn portal-btn-secondary"
                            data-bs-dismiss="modal"
                        >
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            class="btn
                                <?php echo e($docente->estado === 'activo'
                                    ? 'portal-btn-danger'
                                    : 'portal-btn-primary'); ?>"
                        >
                            <?php echo e($docente->estado === 'activo'
                                ? 'Desactivar'
                                : 'Activar'); ?>

                        </button>

                    </div>

                </form>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/docentes/show.blade.php ENDPATH**/ ?>