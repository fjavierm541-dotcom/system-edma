<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?php echo $__env->yieldContent('title', 'Edumerican Academy Honduras'); ?>
    </title>

    <meta
        name="description"
        content="<?php echo $__env->yieldContent('description', 'Edumerican Academy Honduras'); ?>"
    >

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

</head>

<body>

    <?php echo $__env->make('components.website.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('components.website.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('components.website.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH C:\laragon\www\system-edma\resources\views/layouts/web.blade.php ENDPATH**/ ?>