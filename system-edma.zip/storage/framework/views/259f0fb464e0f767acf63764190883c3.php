

<?php $__env->startSection('title', 'Personas | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Personas'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión de personas
            </span>

            <h1>Personas registradas</h1>

            <p>
                Administre la información personal que será utilizada
                posteriormente en los expedientes de estudiantes,
                empleados, docentes y responsables.
            </p>
        </div>

        <div class="portal-page-actions">

            <a
                href="<?php echo e(route('portal.personas.create')); ?>"
                class="btn portal-btn-primary"
            >
                <i class="bi bi-person-plus"></i>
                Nueva persona
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
    <section class="portal-summary-grid">

        <article class="portal-summary-card">

            <div class="portal-summary-icon">
                <i class="bi bi-people"></i>
            </div>

            <div>
                <span>Total registradas</span>
                <strong><?php echo e(number_format($resumen['total'])); ?></strong>
                <small>Registros generales</small>
            </div>

        </article>

        <article class="portal-summary-card">

            <div class="portal-summary-icon portal-summary-icon-success">
                <i class="bi bi-person-check"></i>
            </div>

            <div>
                <span>Personas activas</span>
                <strong><?php echo e(number_format($resumen['activas'])); ?></strong>
                <small>Disponibles para procesos</small>
            </div>

        </article>

        <article class="portal-summary-card">

            <div class="portal-summary-icon portal-summary-icon-muted">
                <i class="bi bi-person-dash"></i>
            </div>

            <div>
                <span>Personas inactivas</span>
                <strong><?php echo e(number_format($resumen['inactivas'])); ?></strong>
                <small>Conservan su historial</small>
            </div>

        </article>

    </section>

    
    <section class="portal-card portal-personas-card">

        <div class="portal-card-header portal-card-header-responsive">

            <div>
                <h2>Directorio de personas</h2>

                <p>
                    Busque por nombre, documento, RTN, correo o teléfono.
                </p>
            </div>

            <span class="portal-results-count">
                <?php echo e($personas->total()); ?>

                <?php echo e($personas->total() === 1 ? 'resultado' : 'resultados'); ?>

            </span>

        </div>

        <div class="portal-filter-area">

            <form
                action="<?php echo e(route('portal.personas.index')); ?>"
                method="GET"
                class="portal-filter-form"
            >

                <div class="portal-search-field">

                    <i class="bi bi-search"></i>

                    <input
                        type="search"
                        name="buscar"
                        value="<?php echo e($termino); ?>"
                        class="form-control"
                        placeholder="Buscar por nombre, documento, correo..."
                        aria-label="Buscar personas"
                    >

                </div>

                <div class="portal-filter-select">

                    <label
                        for="estado"
                        class="visually-hidden"
                    >
                        Filtrar por estado
                    </label>

                    <select
                        name="estado"
                        id="estado"
                        class="form-select"
                    >
                        <option value="">
                            Todos los estados
                        </option>

                        <option
                            value="activo"
                            <?php if($estadoSeleccionado === 'activo'): echo 'selected'; endif; ?>
                        >
                            Activas
                        </option>

                        <option
                            value="inactivo"
                            <?php if($estadoSeleccionado === 'inactivo'): echo 'selected'; endif; ?>
                        >
                            Inactivas
                        </option>
                    </select>

                </div>

                <button
                    type="submit"
                    class="btn portal-btn-primary"
                >
                    <i class="bi bi-funnel"></i>
                    Aplicar
                </button>

                <?php if($termino !== '' || $estadoSeleccionado): ?>
                    <a
                        href="<?php echo e(route('portal.personas.index')); ?>"
                        class="btn portal-btn-secondary"
                    >
                        <i class="bi bi-x-circle"></i>
                        Limpiar
                    </a>
                <?php endif; ?>

            </form>

        </div>

        
        <?php if($personas->isNotEmpty()): ?>

            <div class="portal-table-responsive">

                <table class="table portal-table align-middle mb-0">

                    <thead>
                        <tr>
                            <th>Persona</th>
                            <th>Documento</th>
                            <th>Contacto</th>
                            <th>Residencia</th>
                            <th>Estado</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td>

                                    <div class="portal-person-cell">

                                        <?php if($persona->foto_perfil): ?>

                                            <img
                                                src="<?php echo e(asset('storage/' . $persona->foto_perfil)); ?>"
                                                alt="Fotografía de <?php echo e($persona->nombre_completo); ?>"
                                                class="portal-person-avatar"
                                            >

                                        <?php else: ?>

                                            <span class="portal-person-avatar portal-person-avatar-placeholder">
                                                <?php echo e($persona->iniciales ?: 'PE'); ?>

                                            </span>

                                        <?php endif; ?>

                                        <div class="portal-person-data">

                                            <a
                                                href="<?php echo e(route('portal.personas.show', $persona)); ?>"
                                                class="portal-person-name"
                                            >
                                                <?php echo e($persona->nombre_completo); ?>

                                            </a>

                                            <small>
                                                Registro #<?php echo e(str_pad($persona->id, 5, '0', STR_PAD_LEFT)); ?>

                                            </small>

                                        </div>

                                    </div>

                                </td>

                                <td>

                                    <?php if($persona->numero_documento): ?>

                                        <div class="portal-table-primary">
                                            <?php echo e($persona->numero_documento); ?>

                                        </div>

                                        <small class="portal-table-secondary">
                                            <?php echo e(str($persona->tipo_documento)->replace('_', ' ')->title()); ?>

                                        </small>

                                    <?php else: ?>

                                        <span class="portal-no-data">
                                            Sin documento
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <?php if($persona->correo_personal): ?>

                                        <div class="portal-table-primary portal-text-ellipsis">
                                            <?php echo e($persona->correo_personal); ?>

                                        </div>

                                    <?php endif; ?>

                                    <?php if($persona->telefono_movil): ?>

                                        <small class="portal-table-secondary">
                                            <?php echo e($persona->telefono_movil); ?>


                                            <?php if($persona->telefono_movil_whatsapp): ?>
                                                <i
                                                    class="bi bi-whatsapp portal-whatsapp-icon"
                                                    title="Disponible en WhatsApp"
                                                ></i>
                                            <?php endif; ?>
                                        </small>

                                    <?php endif; ?>

                                    <?php if(!$persona->correo_personal && !$persona->telefono_movil): ?>

                                        <span class="portal-no-data">
                                            Sin contacto
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <?php if(
                                        $persona->ciudad_municipio ||
                                        $persona->departamento_estado ||
                                        $persona->paisResidencia
                                    ): ?>

                                        <div class="portal-table-primary">
                                            <?php echo e($persona->ciudad_municipio ?: 'No especificada'); ?>

                                        </div>

                                        <small class="portal-table-secondary">

                                            <?php echo e(collect([
                                                $persona->departamento_estado,
                                                $persona->paisResidencia?->nombre,
                                            ])->filter()->implode(', ')); ?>


                                        </small>

                                    <?php else: ?>

                                        <span class="portal-no-data">
                                            Sin residencia
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <?php if($persona->estado === 'activo'): ?>

                                        <span class="portal-status-badge portal-status-active">
                                            <span></span>
                                            Activa
                                        </span>

                                    <?php else: ?>

                                        <span class="portal-status-badge portal-status-inactive">
                                            <span></span>
                                            Inactiva
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td class="text-end">

                                    <div class="dropdown">

                                        <button
                                            type="button"
                                            class="portal-table-action"
                                            data-bs-toggle="dropdown"
                                            aria-expanded="false"
                                            aria-label="Opciones para <?php echo e($persona->nombre_completo); ?>"
                                        >
                                            <i class="bi bi-three-dots-vertical"></i>
                                        </button>

                                        <ul class="dropdown-menu dropdown-menu-end portal-actions-menu">

                                            <li>
                                                <a
                                                    href="<?php echo e(route('portal.personas.show', $persona)); ?>"
                                                    class="dropdown-item"
                                                >
                                                    <i class="bi bi-eye"></i>
                                                    Ver expediente
                                                </a>
                                            </li>

                                            <li>
                                                <a
                                                    href="<?php echo e(route('portal.personas.edit', $persona)); ?>"
                                                    class="dropdown-item"
                                                >
                                                    <i class="bi bi-pencil-square"></i>
                                                    Editar información
                                                </a>
                                            </li>

                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>

                                            <li>

                                                <button
                                                    type="button"
                                                    class="dropdown-item
                                                        <?php echo e($persona->estado === 'activo'
                                                            ? 'text-warning-emphasis'
                                                            : 'text-success'); ?>"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#changeStatusModal"
                                                    data-person-id="<?php echo e($persona->id); ?>"
                                                    data-person-name="<?php echo e($persona->nombre_completo); ?>"
                                                    data-person-status="<?php echo e($persona->estado); ?>"
                                                    data-action="<?php echo e(route('portal.personas.cambiar-estado', $persona)); ?>"
                                                >
                                                    <i class="bi
                                                        <?php echo e($persona->estado === 'activo'
                                                            ? 'bi-person-dash'
                                                            : 'bi-person-check'); ?>">
                                                    </i>

                                                    <?php echo e($persona->estado === 'activo'
                                                        ? 'Desactivar persona'
                                                        : 'Activar persona'); ?>

                                                </button>

                                            </li>

                                        </ul>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

            <div class="portal-table-footer">

                <div class="portal-pagination-summary">
                    Mostrando
                    <strong><?php echo e($personas->firstItem()); ?></strong>
                    a
                    <strong><?php echo e($personas->lastItem()); ?></strong>
                    de
                    <strong><?php echo e($personas->total()); ?></strong>
                    registros
                </div>

                <div>
                    <?php echo e($personas->links()); ?>

                </div>

            </div>

        <?php else: ?>

            <div class="portal-empty-state portal-empty-state-large">

                <div class="portal-empty-icon">
                    <i class="bi bi-person-search"></i>
                </div>

                <?php if($termino !== '' || $estadoSeleccionado): ?>

                    <h3>No se encontraron coincidencias</h3>

                    <p>
                        No hay personas que coincidan con los criterios
                        de búsqueda seleccionados.
                    </p>

                    <a
                        href="<?php echo e(route('portal.personas.index')); ?>"
                        class="btn portal-btn-secondary mt-3"
                    >
                        Limpiar filtros
                    </a>

                <?php else: ?>

                    <h3>Todavía no hay personas registradas</h3>

                    <p>
                        Registre la primera persona para comenzar a construir
                        los expedientes del sistema.
                    </p>

                    <a
                        href="<?php echo e(route('portal.personas.create')); ?>"
                        class="btn portal-btn-primary mt-3"
                    >
                        <i class="bi bi-person-plus"></i>
                        Registrar primera persona
                    </a>

                <?php endif; ?>

            </div>

        <?php endif; ?>

    </section>

    
    <div
        class="modal fade"
        id="changeStatusModal"
        tabindex="-1"
        aria-labelledby="changeStatusModalLabel"
        aria-hidden="true"
    >
        <div class="modal-dialog modal-dialog-centered">

            <div class="modal-content portal-modal">

                <form
                    method="POST"
                    id="changeStatusForm"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <div class="modal-header">

                        <div>
                            <span class="portal-modal-eyebrow">
                                Confirmación
                            </span>

                            <h2
                                class="modal-title"
                                id="changeStatusModalLabel"
                            >
                                Cambiar estado
                            </h2>
                        </div>

                        <button
                            type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Cerrar"
                        ></button>

                    </div>

                    <div class="modal-body">

                        <div class="portal-modal-warning-icon">
                            <i class="bi bi-person-gear"></i>
                        </div>

                        <p id="changeStatusMessage" class="mb-0"></p>

                    </div>

                    <div class="modal-footer">

                        <button
                            type="button"
                            class="btn portal-btn-secondary"
                            data-bs-dismiss="modal"
                        >
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            class="btn portal-btn-primary"
                            id="changeStatusSubmit"
                        >
                            Confirmar
                        </button>

                    </div>

                </form>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const modal = document.getElementById('changeStatusModal');
            const form = document.getElementById('changeStatusForm');
            const message = document.getElementById('changeStatusMessage');
            const submitButton = document.getElementById('changeStatusSubmit');

            if (!modal || !form || !message || !submitButton) {
                return;
            }

            modal.addEventListener('show.bs.modal', event => {
                const button = event.relatedTarget;

                const personName = button.dataset.personName;
                const personStatus = button.dataset.personStatus;
                const action = button.dataset.action;

                const willDeactivate = personStatus === 'activo';

                form.action = action;

                message.textContent = willDeactivate
                    ? `¿Desea desactivar a ${personName}? La información histórica se conservará.`
                    : `¿Desea activar nuevamente a ${personName}?`;

                submitButton.textContent = willDeactivate
                    ? 'Desactivar'
                    : 'Activar';

                submitButton.classList.toggle(
                    'portal-btn-danger',
                    willDeactivate
                );

                submitButton.classList.toggle(
                    'portal-btn-primary',
                    !willDeactivate
                );
            });
        });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/personas/index.blade.php ENDPATH**/ ?>