

<?php $__env->startSection('title', 'Nuevo docente | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Nuevo docente'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión académica
            </span>

            <h1>Registrar docente</h1>

            <p>
                Seleccione un empleado activo y complete la
                información correspondiente a su perfil docente.
            </p>
        </div>

        <div class="portal-page-actions">

            <a
                href="<?php echo e(route('portal.docentes.index')); ?>"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver al listado
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form
        action="<?php echo e(route('portal.docentes.store')); ?>"
        method="POST"
        id="docenteForm"
        novalidate
    >
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('portal.docentes.partials._form', [
            'docente' => null,
            'modoEdicion' => false,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/docentes/create.blade.php ENDPATH**/ ?>