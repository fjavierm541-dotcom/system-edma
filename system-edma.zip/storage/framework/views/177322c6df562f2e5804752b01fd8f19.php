<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="csrf-token"
        content="<?php echo e(csrf_token()); ?>"
    >

    <title>
        <?php echo $__env->yieldContent('title', 'Portal EDMA'); ?>
    </title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="portal-body">

    <div class="portal-wrapper" id="portalWrapper">

        
        <?php if (isset($component)) { $__componentOriginal2d3df6335a20bad055c2319f151e56c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d3df6335a20bad055c2319f151e56c6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('portal.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d3df6335a20bad055c2319f151e56c6)): ?>
<?php $attributes = $__attributesOriginal2d3df6335a20bad055c2319f151e56c6; ?>
<?php unset($__attributesOriginal2d3df6335a20bad055c2319f151e56c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d3df6335a20bad055c2319f151e56c6)): ?>
<?php $component = $__componentOriginal2d3df6335a20bad055c2319f151e56c6; ?>
<?php unset($__componentOriginal2d3df6335a20bad055c2319f151e56c6); ?>
<?php endif; ?>

        
        <div
            class="portal-sidebar-overlay"
            id="portalSidebarOverlay"
            aria-hidden="true"
        ></div>

        <div class="portal-main">

            
            <?php if (isset($component)) { $__componentOriginale428438d6a796fc87d49371e9311adfd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale428438d6a796fc87d49371e9311adfd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('portal.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale428438d6a796fc87d49371e9311adfd)): ?>
<?php $attributes = $__attributesOriginale428438d6a796fc87d49371e9311adfd; ?>
<?php unset($__attributesOriginale428438d6a796fc87d49371e9311adfd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale428438d6a796fc87d49371e9311adfd)): ?>
<?php $component = $__componentOriginale428438d6a796fc87d49371e9311adfd; ?>
<?php unset($__componentOriginale428438d6a796fc87d49371e9311adfd); ?>
<?php endif; ?>

            <main class="portal-content">

                <div class="portal-content-container">

                    
                    <?php if (! empty(trim($__env->yieldContent('page-header')))): ?>
                        <div class="portal-page-header">
                            <?php echo $__env->yieldContent('page-header'); ?>
                        </div>
                    <?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginal324f712180f47bbe4f056fe403783110 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal324f712180f47bbe4f056fe403783110 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal.alerts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('portal.alerts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal324f712180f47bbe4f056fe403783110)): ?>
<?php $attributes = $__attributesOriginal324f712180f47bbe4f056fe403783110; ?>
<?php unset($__attributesOriginal324f712180f47bbe4f056fe403783110); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal324f712180f47bbe4f056fe403783110)): ?>
<?php $component = $__componentOriginal324f712180f47bbe4f056fe403783110; ?>
<?php unset($__componentOriginal324f712180f47bbe4f056fe403783110); ?>
<?php endif; ?>

                    
                    <?php echo $__env->yieldContent('content'); ?>

                </div>

            </main>

            <?php if (isset($component)) { $__componentOriginal4294bdea13e99034632c8d2d2b35e749 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4294bdea13e99034632c8d2d2b35e749 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.portal.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('portal.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4294bdea13e99034632c8d2d2b35e749)): ?>
<?php $attributes = $__attributesOriginal4294bdea13e99034632c8d2d2b35e749; ?>
<?php unset($__attributesOriginal4294bdea13e99034632c8d2d2b35e749); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4294bdea13e99034632c8d2d2b35e749)): ?>
<?php $component = $__componentOriginal4294bdea13e99034632c8d2d2b35e749; ?>
<?php unset($__componentOriginal4294bdea13e99034632c8d2d2b35e749); ?>
<?php endif; ?>

        </div>

    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\system-edma\resources\views/layouts/portal.blade.php ENDPATH**/ ?>