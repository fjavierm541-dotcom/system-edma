

<?php $__env->startSection('title', 'Editar período | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Editar período'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión académica
            </span>

            <h1>Editar período académico</h1>

            <p>
                Actualice la planificación de
                <?php echo e($periodo->nombre); ?>.
            </p>
        </div>

        <div class="portal-page-actions">

            <a
                href="<?php echo e(route(
                    'portal.periodos.show',
                    $periodo
                )); ?>"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver al período
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form
        action="<?php echo e(route(
            'portal.periodos.update',
            $periodo
        )); ?>"
        method="POST"
        novalidate
    >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <?php echo $__env->make('portal.periodos.partials._form', [
            'periodo' => $periodo,
            'modoEdicion' => true,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/periodos/edit.blade.php ENDPATH**/ ?>