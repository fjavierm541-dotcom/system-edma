<?php
    $modoEdicion = $modoEdicion ?? false;

    $programaIdActual = old(
        'programa_id',
        $nivel->programa_id
            ?? $programaSeleccionado?->id
            ?? ''
    );

    $ordenActual = old(
        'orden',
        $nivel->orden ?? ''
    );

    $duracionActual = old(
        'duracion_semanas',
        $nivel->duracion_semanas ?? 12
    );

    $notaMinimaActual = old(
        'nota_minima_aprobacion',
        $nivel->nota_minima_aprobacion ?? '70.00'
    );

    $estadoActual = old(
        'estado',
        $nivel->estado ?? 'activo'
    );
?>

<div class="row g-4">

    
    <div class="col-12 col-xl-8">

        <section class="portal-card portal-form-card">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-layers"></i>
                </div>

                <div>
                    <h2>Información del nivel</h2>

                    <p>
                        Configure la identificación y posición
                        académica del nivel dentro del programa.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <div class="row g-3">

                    
                    <div class="col-12">

                        <label
                            for="programa_id"
                            class="form-label portal-form-label"
                        >
                            Programa académico
                            <span class="portal-required">*</span>
                        </label>

                        <select
                            name="programa_id"
                            id="programa_id"
                            class="form-select portal-form-control
                                <?php $__errorArgs = ['programa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required
                        >
                            <option value="">
                                Seleccione un programa
                            </option>

                            <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($programa->id); ?>"
                                    data-segment="<?php echo e($programa->segmento); ?>"
                                    <?php if(
                                        (string) $programaIdActual
                                        === (string) $programa->id
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($programa->nombre); ?>

                                    — <?php echo e($programa->codigo); ?>

                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                        <?php $__errorArgs = ['programa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="portal-form-help">
                            El nivel pertenecerá exclusivamente al
                            programa seleccionado.
                        </div>

                    </div>

                    
                    <div class="col-12 col-md-4">

                        <label
                            for="codigo"
                            class="form-label portal-form-label"
                        >
                            Código
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="text"
                            name="codigo"
                            id="codigo"
                            value="<?php echo e(old(
                                'codigo',
                                $nivel->codigo ?? ''
                            )); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="20"
                            autocomplete="off"
                            placeholder="Ej. A0"
                            required
                        >

                        <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="portal-form-help">
                            Ejemplo: A0, A1, A2.
                        </div>

                    </div>

                    
                    <div class="col-12 col-md-5">

                        <label
                            for="nombre"
                            class="form-label portal-form-label"
                        >
                            Nombre
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="text"
                            name="nombre"
                            id="nombre"
                            value="<?php echo e(old(
                                'nombre',
                                $nivel->nombre ?? ''
                            )); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="100"
                            placeholder="Ej. A0"
                            required
                        >

                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="portal-form-help">
                            Puede coincidir con el código si esa es
                            la nomenclatura oficial.
                        </div>

                    </div>

                    
                    <div class="col-12 col-md-3">

                        <label
                            for="orden"
                            class="form-label portal-form-label"
                        >
                            Orden
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="text"
                            name="orden"
                            id="orden"
                            value="<?php echo e($ordenActual); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['orden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="3"
                            inputmode="numeric"
                            pattern="[0-9]*"
                            placeholder="1"
                            required
                        >

                        <?php $__errorArgs = ['orden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="portal-form-help">
                            Posición dentro del programa.
                        </div>

                    </div>

                    
                    <div class="col-12 col-md-6">

                        <label
                            for="duracion_semanas"
                            class="form-label portal-form-label"
                        >
                            Duración
                            <span class="portal-required">*</span>
                        </label>

                        <div class="input-group">

                            <input
                                type="text"
                                name="duracion_semanas"
                                id="duracion_semanas"
                                value="<?php echo e($duracionActual); ?>"
                                class="form-control portal-form-control
                                    <?php $__errorArgs = ['duracion_semanas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                maxlength="3"
                                inputmode="numeric"
                                pattern="[0-9]*"
                                required
                            >

                            <span class="input-group-text">
                                semanas
                            </span>

                            <?php $__errorArgs = ['duracion_semanas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        <div class="portal-form-help">
                            La duración actual de los niveles de EDMA
                            es de 12 semanas.
                        </div>

                    </div>

                    
                    <div class="col-12 col-md-6">

                        <label
                            for="nota_minima_aprobacion"
                            class="form-label portal-form-label"
                        >
                            Nota mínima de aprobación
                        </label>

                        <div class="input-group">

                            <input
                                type="number"
                                name="nota_minima_aprobacion"
                                id="nota_minima_aprobacion"
                                value="<?php echo e($notaMinimaActual); ?>"
                                class="form-control portal-form-control
                                    <?php $__errorArgs = ['nota_minima_aprobacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                min="0"
                                max="100"
                                step="0.01"
                            >

                            <span class="input-group-text">
                                / 100
                            </span>

                            <?php $__errorArgs = ['nota_minima_aprobacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        <div class="portal-form-help">
                            La nota mínima oficial es 70 sobre 100.
                        </div>

                    </div>

                    
                    <div class="col-12">

                        <label
                            for="descripcion"
                            class="form-label portal-form-label"
                        >
                            Descripción
                        </label>

                        <textarea
                            name="descripcion"
                            id="descripcion"
                            rows="4"
                            maxlength="2000"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            placeholder="Descripción general del nivel..."
                        ><?php echo e(old(
                            'descripcion',
                            $nivel->descripcion ?? ''
                        )); ?></textarea>

                        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="portal-form-text-counter">

                            <span>
                                Campo opcional.
                            </span>

                            <span>
                                <strong id="descripcionCounter">0</strong>
                                / 2000
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </section>

    </div>

    
    <div class="col-12 col-xl-4">

        <div class="portal-form-sidebar">

            
            <section class="portal-card portal-form-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-sliders"></i>
                    </div>

                    <div>
                        <h2>Configuración</h2>

                        <p>
                            Estado académico del nivel.
                        </p>
                    </div>

                </div>

                <div class="portal-form-section-body">

                    <label
                        for="estado"
                        class="form-label portal-form-label"
                    >
                        Estado
                    </label>

                    <select
                        name="estado"
                        id="estado"
                        class="form-select portal-form-control
                            <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        required
                    >
                        <option
                            value="activo"
                            <?php if($estadoActual === 'activo'): echo 'selected'; endif; ?>
                        >
                            Activo
                        </option>

                        <option
                            value="inactivo"
                            <?php if($estadoActual === 'inactivo'): echo 'selected'; endif; ?>
                        >
                            Inactivo
                        </option>

                    </select>

                    <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="portal-form-help mt-2">
                        Los niveles inactivos conservarán todo
                        su historial académico.
                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-form-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-mortarboard"></i>
                    </div>

                    <div>
                        <h2>Referencia académica</h2>
                        <p>Configuración actual de EDMA.</p>
                    </div>

                </div>

                <div class="portal-form-section-body">

                    <ul class="portal-form-guidelines mb-0">

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                Los programas manejan actualmente
                                7 niveles académicos.
                            </span>
                        </li>

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                Cada nivel tiene una duración
                                estándar de 12 semanas.
                            </span>
                        </li>

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                La nota mínima de aprobación
                                es 70 sobre 100.
                            </span>
                        </li>

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                Los códigos académicos pueden utilizar
                                nomenclatura como A0, A1 y A2.
                            </span>
                        </li>

                    </ul>

                </div>

            </section>

            
            <section class="portal-card portal-form-actions-card">

                <div class="portal-form-actions">

                    <button
                        type="submit"
                        class="btn portal-btn-primary w-100"
                    >
                        <i class="bi bi-check2-circle"></i>

                        <?php echo e($modoEdicion
                            ? 'Guardar cambios'
                            : 'Registrar nivel'); ?>

                    </button>

                    <a
                        href="<?php echo e($modoEdicion
                            ? route(
                                'portal.niveles.show',
                                $nivel
                            )
                            : route('portal.niveles.index')); ?>"
                        class="btn portal-btn-secondary w-100"
                    >
                        Cancelar
                    </a>

                </div>

            </section>

        </div>

    </div>

</div>

<?php $__env->startPush('scripts'); ?>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const code = document.getElementById(
            'codigo'
        );

        const order = document.getElementById(
            'orden'
        );

        const duration = document.getElementById(
            'duracion_semanas'
        );

        const description = document.getElementById(
            'descripcion'
        );

        const descriptionCounter = document.getElementById(
            'descripcionCounter'
        );

        const allowOnlyDigits = (
            element,
            maximumLength
        ) => {
            if (!element) {
                return;
            }

            element.value = element.value
                .replace(/\D/g, '')
                .slice(0, maximumLength);
        };

        code?.addEventListener('input', () => {
            code.value = code.value
                .toUpperCase()
                .replace(/[^A-Z0-9_-]/g, '')
                .slice(0, 20);
        });

        order?.addEventListener(
            'input',
            () => allowOnlyDigits(order, 3)
        );

        duration?.addEventListener(
            'input',
            () => allowOnlyDigits(duration, 3)
        );

        const updateDescriptionCounter = () => {
            if (
                !description ||
                !descriptionCounter
            ) {
                return;
            }

            descriptionCounter.textContent =
                description.value.length;
        };

        description?.addEventListener(
            'input',
            updateDescriptionCounter
        );

        updateDescriptionCounter();
    });
</script>

<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/niveles/partials/_form.blade.php ENDPATH**/ ?>