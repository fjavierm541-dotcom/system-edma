

<?php $__env->startSection('title', 'Nuevo nivel | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Nuevo nivel'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión académica
            </span>

            <h1>Registrar nivel académico</h1>

            <p>
                Configure un nivel dentro de uno de los
                programas académicos de EDMA.
            </p>
        </div>

        <div class="portal-page-actions">

            <a
                href="<?php echo e(route('portal.niveles.index')); ?>"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form
        action="<?php echo e(route('portal.niveles.store')); ?>"
        method="POST"
        novalidate
    >
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('portal.niveles.partials._form', [
            'nivel' => null,
            'modoEdicion' => false,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/niveles/create.blade.php ENDPATH**/ ?>