

<?php $__env->startSection('title', 'Nueva persona | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Nueva persona'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión de personas
            </span>

            <h1>Registrar nueva persona</h1>

            <p>
                Ingrese la información general de la persona.
                Posteriormente podrá asociarse como estudiante,
                empleado, docente o responsable.
            </p>
        </div>

        <div class="portal-page-actions">

            <a
                href="<?php echo e(route('portal.personas.index')); ?>"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver al listado
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form
        action="<?php echo e(route('portal.personas.store')); ?>"
        method="POST"
        enctype="multipart/form-data"
        id="personaForm"
        novalidate
    >
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('portal.personas.partials._form', [
            'persona' => null,
            'modoEdicion' => false,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/personas/create.blade.php ENDPATH**/ ?>