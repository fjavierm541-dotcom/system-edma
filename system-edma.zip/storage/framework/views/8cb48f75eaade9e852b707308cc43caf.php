<footer class="portal-footer">

    <span>
        &copy; <?php echo e(date('Y')); ?> Edumerican Academy Honduras
    </span>

    <span>
        Sistema de Gestión Académica EDMA
    </span>

</footer><?php /**PATH C:\laragon\www\system-edma\resources\views/components/portal/footer.blade.php ENDPATH**/ ?>