<?php
    $modoEdicion = $modoEdicion ?? false;

    $fechaInicio = old(
        'fecha_inicio',
        $periodo?->fecha_inicio?->format('Y-m-d')
    );

    $fechaFin = old(
        'fecha_fin',
        $periodo?->fecha_fin?->format('Y-m-d')
    );

    $fechaInicioMatricula = old(
        'fecha_inicio_matricula',
        $periodo?->fecha_inicio_matricula?->format('Y-m-d')
    );

    $fechaFinMatricula = old(
        'fecha_fin_matricula',
        $periodo?->fecha_fin_matricula?->format('Y-m-d')
    );

    $estadoActual = old(
        'estado',
        $periodo->estado ?? 'activo'
    );
?>

<div class="row g-4">

    <div class="col-12 col-xl-8">

        
        <section class="portal-card portal-form-card">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-calendar3"></i>
                </div>

                <div>
                    <h2>Información del período</h2>

                    <p>
                        Identifique el período académico que se utilizará
                        para organizar grupos, matrículas y actividades.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <div class="row g-3">

                    <div class="col-12">

                        <label
                            for="nombre"
                            class="form-label portal-form-label"
                        >
                            Nombre del período
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="text"
                            name="nombre"
                            id="nombre"
                            value="<?php echo e(old(
                                'nombre',
                                $periodo->nombre ?? ''
                            )); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="100"
                            placeholder="Ej. Tercer período académico 2026"
                            required
                        >

                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="portal-form-help">
                            El código institucional será asignado automáticamente
                            al registrar el período.
                        </div>

                    </div>

                </div>

            </div>

        </section>

        
        <section class="portal-card portal-form-card">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-person-check"></i>
                </div>

                <div>
                    <h2>Período de matrícula</h2>

                    <p>
                        Defina las fechas durante las cuales se permitirá
                        realizar matrículas para este período.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <div class="row g-3">

                    <div class="col-12 col-md-6">

                        <label
                            for="fecha_inicio_matricula"
                            class="form-label portal-form-label"
                        >
                            Inicio de matrícula
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="date"
                            name="fecha_inicio_matricula"
                            id="fecha_inicio_matricula"
                            value="<?php echo e($fechaInicioMatricula); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['fecha_inicio_matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required
                        >

                        <?php $__errorArgs = ['fecha_inicio_matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="fecha_fin_matricula"
                            class="form-label portal-form-label"
                        >
                            Cierre de matrícula
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="date"
                            name="fecha_fin_matricula"
                            id="fecha_fin_matricula"
                            value="<?php echo e($fechaFinMatricula); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['fecha_fin_matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required
                        >

                        <?php $__errorArgs = ['fecha_fin_matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12">

                        <div class="portal-inline-notice">

                            <i class="bi bi-info-circle"></i>

                            <div>
                                <strong>Ventana de matrícula</strong>

                                <span>
                                    Fuera de estas fechas, el período no se
                                    considerará abierto para nuevas matrículas.
                                </span>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </section>

        
        <section class="portal-card portal-form-card">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-calendar-range"></i>
                </div>

                <div>
                    <h2>Desarrollo académico</h2>

                    <p>
                        Indique cuándo comienzan y finalizan las actividades
                        académicas correspondientes al período.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <div class="row g-3">

                    <div class="col-12 col-md-6">

                        <label
                            for="fecha_inicio"
                            class="form-label portal-form-label"
                        >
                            Inicio del período
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="date"
                            name="fecha_inicio"
                            id="fecha_inicio"
                            value="<?php echo e($fechaInicio); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required
                        >

                        <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="fecha_fin"
                            class="form-label portal-form-label"
                        >
                            Finalización del período
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="date"
                            name="fecha_fin"
                            id="fecha_fin"
                            value="<?php echo e($fechaFin); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required
                        >

                        <?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12">

                        <div class="portal-inline-notice">

                            <i class="bi bi-calendar-check"></i>

                            <div>
                                <strong>Fechas académicas</strong>

                                <span>
                                    Los grupos creados para este período podrán
                                    organizarse dentro de estas fechas.
                                </span>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </section>

        
        <section class="portal-card portal-form-card mb-0">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-journal-text"></i>
                </div>

                <div>
                    <h2>Observaciones</h2>

                    <p>
                        Registre cualquier información adicional
                        que deba considerarse durante este período.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <textarea
                    name="observaciones"
                    id="observaciones"
                    rows="5"
                    maxlength="2000"
                    class="form-control portal-form-control
                        <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                ><?php echo e(old(
                    'observaciones',
                    $periodo->observaciones ?? ''
                )); ?></textarea>

                <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="portal-form-text-counter">

                    <span>
                        Campo opcional.
                    </span>

                    <span>
                        <strong id="observacionesCounter">0</strong>
                        / 2000
                    </span>

                </div>

            </div>

        </section>

    </div>

    
    <div class="col-12 col-xl-4">

        <div class="portal-form-sidebar">

            <section class="portal-card portal-form-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-toggle-on"></i>
                    </div>

                    <div>
                        <h2>Estado</h2>

                        <p>
                            Disponibilidad del período académico.
                        </p>
                    </div>

                </div>

                <div class="portal-form-section-body">

                    <label
                        for="estado"
                        class="form-label portal-form-label"
                    >
                        Estado del período
                    </label>

                    <select
                        name="estado"
                        id="estado"
                        class="form-select portal-form-control
                            <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        required
                    >
                        <option
                            value="activo"
                            <?php if($estadoActual === 'activo'): echo 'selected'; endif; ?>
                        >
                            Activo
                        </option>

                        <option
                            value="inactivo"
                            <?php if($estadoActual === 'inactivo'): echo 'selected'; endif; ?>
                        >
                            Inactivo
                        </option>

                    </select>

                    <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="portal-form-help mt-2">
                        Un período inactivo conservará todos los
                        grupos y registros asociados.
                    </div>

                </div>

            </section>

            <section class="portal-card portal-form-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-lightbulb"></i>
                    </div>

                    <div>
                        <h2>Antes de guardar</h2>

                        <p>
                            Revise estos datos para evitar inconsistencias.
                        </p>
                    </div>

                </div>

                <div class="portal-form-section-body">

                    <ul class="portal-form-guidelines mb-0">

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                Verifique que el período de matrícula
                                tenga una fecha de inicio y cierre correcta.
                            </span>
                        </li>

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                Confirme que las fechas académicas coincidan
                                con la planificación establecida.
                            </span>
                        </li>

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                Los grupos deberán asociarse posteriormente
                                al período correspondiente.
                            </span>
                        </li>

                    </ul>

                </div>

            </section>

            <section class="portal-card portal-form-actions-card">

                <div class="portal-form-actions">

                    <button
                        type="submit"
                        class="btn portal-btn-primary w-100"
                    >
                        <i class="bi bi-check2-circle"></i>

                        <?php echo e($modoEdicion
                            ? 'Guardar cambios'
                            : 'Registrar período'); ?>

                    </button>

                    <a
                        href="<?php echo e($modoEdicion
                            ? route(
                                'portal.periodos.show',
                                $periodo
                            )
                            : route('portal.periodos.index')); ?>"
                        class="btn portal-btn-secondary w-100"
                    >
                        Cancelar
                    </a>

                </div>

            </section>

        </div>

    </div>

</div>

<?php $__env->startPush('scripts'); ?>

<script>
    document.addEventListener('DOMContentLoaded', () => {
    
        const enrollmentStart = document.getElementById(
            'fecha_inicio_matricula'
        );

        const enrollmentEnd = document.getElementById(
            'fecha_fin_matricula'
        );

        const academicStart = document.getElementById(
            'fecha_inicio'
        );

        const academicEnd = document.getElementById(
            'fecha_fin'
        );

        const observations = document.getElementById(
            'observaciones'
        );

        const observationsCounter = document.getElementById(
            'observacionesCounter'
        );

       

        const updateDates = () => {
            if (enrollmentStart && enrollmentEnd) {
                enrollmentEnd.min =
                    enrollmentStart.value || '';
            }

            if (academicStart && academicEnd) {
                academicEnd.min =
                    academicStart.value || '';
            }

            if (academicEnd && enrollmentEnd) {
                enrollmentEnd.max =
                    academicEnd.value || '';
            }
        };

        enrollmentStart?.addEventListener(
            'change',
            updateDates
        );

        academicStart?.addEventListener(
            'change',
            updateDates
        );

        academicEnd?.addEventListener(
            'change',
            updateDates
        );

        const updateObservationsCounter = () => {
            if (!observations || !observationsCounter) {
                return;
            }

            observationsCounter.textContent =
                observations.value.length;
        };

        observations?.addEventListener(
            'input',
            updateObservationsCounter
        );

        updateDates();
        updateObservationsCounter();
    });
</script>

<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/periodos/partials/_form.blade.php ENDPATH**/ ?>