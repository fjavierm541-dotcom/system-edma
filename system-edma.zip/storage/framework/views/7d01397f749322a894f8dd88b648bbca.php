

<?php $__env->startSection('title', $persona->nombre_completo . ' | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Expediente de persona'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión de personas
            </span>

            <h1><?php echo e($persona->nombre_completo); ?></h1>

            <p>
                Consulte la información general, documentos y estado
                administrativo de la persona.
            </p>
        </div>

        <div class="portal-page-actions portal-page-actions-group">

            <a
                href="<?php echo e(route('portal.personas.index')); ?>"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver
            </a>

            <a
                href="<?php echo e(route('portal.personas.edit', $persona)); ?>"
                class="btn portal-btn-primary"
            >
                <i class="bi bi-pencil-square"></i>
                Editar información
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row g-4">

        
        <div class="col-12 col-xl-4 col-xxl-3">

            <section class="portal-card portal-profile-card">

                <div class="portal-profile-cover"></div>

                <div class="portal-profile-content">

                    <div class="portal-profile-photo">

                        <?php if($persona->foto_perfil): ?>

                            <img
                                src="<?php echo e(asset('storage/' . $persona->foto_perfil)); ?>"
                                alt="Fotografía de <?php echo e($persona->nombre_completo); ?>"
                            >

                        <?php else: ?>

                            <span>
                                <?php echo e($persona->iniciales ?: 'PE'); ?>

                            </span>

                        <?php endif; ?>

                    </div>

                    <h2><?php echo e($persona->nombre_completo); ?></h2>

                    <span class="portal-profile-code">
                        Registro #<?php echo e(str_pad($persona->id, 5, '0', STR_PAD_LEFT)); ?>

                    </span>

                    <div class="mt-3">

                        <?php if($persona->estado === 'activo'): ?>

                            <span class="portal-status-badge portal-status-active">
                                <span></span>
                                Persona activa
                            </span>

                        <?php else: ?>

                            <span class="portal-status-badge portal-status-inactive">
                                <span></span>
                                Persona inactiva
                            </span>

                        <?php endif; ?>

                    </div>

                </div>

                <div class="portal-profile-summary">

                    <div>
                        <span>Registrada</span>

                        <strong>
                            <?php echo e($persona->created_at?->translatedFormat('d M Y')); ?>

                        </strong>
                    </div>

                    <div>
                        <span>Actualizada</span>

                        <strong>
                            <?php echo e($persona->updated_at?->diffForHumans()); ?>

                        </strong>
                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-profile-actions-card">

                <div class="portal-card-header">

                    <div>
                        <h2>Acciones</h2>
                        <p>Operaciones disponibles.</p>
                    </div>

                </div>

                <div class="portal-profile-actions">

                    <a
                        href="<?php echo e(route('portal.personas.edit', $persona)); ?>"
                        class="portal-profile-action"
                    >
                        <span>
                            <i class="bi bi-pencil-square"></i>
                        </span>

                        <div>
                            <strong>Editar información</strong>
                            <small>Actualizar datos personales</small>
                        </div>

                        <i class="bi bi-chevron-right"></i>
                    </a>

                    <?php if($persona->estudiante): ?>

                        <a
                            href="<?php echo e(route(
                                'portal.estudiantes.show',
                                $persona->estudiante
                            )); ?>"
                            class="portal-profile-action"
                        >
                            <span>
                                <i class="bi bi-mortarboard"></i>
                            </span>

                            <div>
                                <strong>Ver expediente estudiantil</strong>

                                <small>
                                    <?php echo e($persona->estudiante->codigo_estudiante); ?>

                                </small>
                            </div>

                            <i class="bi bi-chevron-right"></i>
                        </a>

                    <?php elseif($persona->estado === 'activo'): ?>

                        <a
                            href="<?php echo e(route(
                                'portal.estudiantes.create',
                                ['persona' => $persona->id]
                            )); ?>"
                            class="portal-profile-action"
                        >
                            <span>
                                <i class="bi bi-person-plus"></i>
                            </span>

                            <div>
                                <strong>Registrar como estudiante</strong>

                                <small>
                                    Crear expediente estudiantil
                                </small>
                            </div>

                            <i class="bi bi-chevron-right"></i>
                        </a>

                    <?php endif; ?>

                    <?php if($persona->empleado): ?>

    <a
        href="<?php echo e(route(
            'portal.empleados.show',
            $persona->empleado
        )); ?>"
        class="portal-profile-action"
    >
        <span>
            <i class="bi bi-briefcase"></i>
        </span>

        <div>
            <strong>Ver expediente laboral</strong>

            <small>
                <?php echo e($persona->empleado->codigo_empleado); ?>

            </small>
        </div>

        <i class="bi bi-chevron-right"></i>
    </a>

<?php elseif($persona->estado === 'activo'): ?>

    <a
        href="<?php echo e(route(
            'portal.empleados.create',
            ['persona' => $persona->id]
        )); ?>"
        class="portal-profile-action"
    >
        <span>
            <i class="bi bi-person-badge"></i>
        </span>

        <div>
            <strong>Registrar como empleado</strong>

            <small>
                Crear expediente laboral
            </small>
        </div>

        <i class="bi bi-chevron-right"></i>
    </a>

<?php endif; ?>

                    <?php if(
                        $persona->telefono_movil &&
                        $persona->telefono_movil_whatsapp
                    ): ?>

                        <?php
                            $numeroWhatsapp = preg_replace(
                                '/\D+/',
                                '',
                                $persona->telefono_movil
                            );

                            if (
                                strlen($numeroWhatsapp) === 8 &&
                                $persona->paisResidencia?->codigo_iso2 === 'HN'
                            ) {
                                $numeroWhatsapp = '504' . $numeroWhatsapp;
                            }
                        ?>

                        <a
                            href="https://wa.me/<?php echo e($numeroWhatsapp); ?>"
                            target="_blank"
                            rel="noopener noreferrer"
                            class="portal-profile-action"
                        >
                            <span class="portal-profile-action-success">
                                <i class="bi bi-whatsapp"></i>
                            </span>

                            <div>
                                <strong>Contactar por WhatsApp</strong>
                                <small><?php echo e($persona->telefono_movil); ?></small>
                            </div>

                            <i class="bi bi-box-arrow-up-right"></i>
                        </a>

                    <?php endif; ?>

                    <button
                        type="button"
                        class="portal-profile-action portal-profile-action-button"
                        data-bs-toggle="modal"
                        data-bs-target="#changeStatusModal"
                    >
                        <span>
                            <i class="bi bi-person-gear"></i>
                        </span>

                        <div>
                            <strong>
                                <?php echo e($persona->estado === 'activo'
                                    ? 'Desactivar persona'
                                    : 'Activar persona'); ?>

                            </strong>

                            <small>
                                <?php echo e($persona->estado === 'activo'
                                    ? 'Conservará su información histórica'
                                    : 'Habilitar nuevamente el registro'); ?>

                            </small>
                        </div>

                        <i class="bi bi-chevron-right"></i>
                    </button>

                </div>

            </section>

        </div>

        
        <div class="col-12 col-xl-8 col-xxl-9">

            
            <section class="portal-card portal-detail-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-person-vcard"></i>
                    </div>

                    <div>
                        <h2>Datos personales</h2>
                        <p>Información general de la persona.</p>
                    </div>

                </div>

                <div class="portal-detail-grid">

                    <div class="portal-detail-item">
                        <span>Nombre completo</span>
                        <strong><?php echo e($persona->nombre_completo); ?></strong>
                    </div>

                    <div class="portal-detail-item">
                        <span>Fecha de nacimiento</span>

                        <strong>
                            <?php echo e($persona->fecha_nacimiento
                                ? $persona->fecha_nacimiento->translatedFormat('d \d\e F \d\e Y')
                                : 'No especificada'); ?>

                        </strong>

                        <?php if($persona->fecha_nacimiento): ?>
                            <small>
                                <?php echo e($persona->fecha_nacimiento->age); ?> años
                            </small>
                        <?php endif; ?>
                    </div>

                    <div class="portal-detail-item">
                        <span>Sexo</span>

                        <strong>
                            <?php echo e($persona->sexo
                                ? str($persona->sexo)->replace('_', ' ')->title()
                                : 'No especificado'); ?>

                        </strong>
                    </div>

                    <div class="portal-detail-item">
                        <span>Estado civil</span>

                        <strong>
                            <?php echo e($persona->estado_civil
                                ? str($persona->estado_civil)->replace('_', ' ')->title()
                                : 'No especificado'); ?>

                        </strong>
                    </div>

                    <div class="portal-detail-item">
                        <span>Nacionalidad</span>
                        <strong><?php echo e($persona->nacionalidad ?: 'No especificada'); ?></strong>
                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-detail-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-credit-card-2-front"></i>
                    </div>

                    <div>
                        <h2>Identificación</h2>
                        <p>Documentos oficiales registrados.</p>
                    </div>

                </div>

                <div class="portal-detail-grid">

                    <div class="portal-detail-item">
                        <span>Tipo de documento</span>

                        <strong>
                            <?php echo e($persona->tipo_documento
                                ? str($persona->tipo_documento)->replace('_', ' ')->title()
                                : 'Sin documento'); ?>

                        </strong>
                    </div>

                    <div class="portal-detail-item">
                        <span>Número de documento</span>
                        <strong><?php echo e($persona->numero_documento ?: 'No registrado'); ?></strong>
                    </div>

                    <div class="portal-detail-item">
                        <span>RTN</span>
                        <strong><?php echo e($persona->rtn ?: 'No registrado'); ?></strong>
                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-detail-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-telephone"></i>
                    </div>

                    <div>
                        <h2>Información de contacto</h2>
                        <p>Correo electrónico y teléfonos.</p>
                    </div>

                </div>

                <div class="portal-detail-grid">

                    <div class="portal-detail-item">
                        <span>Correo personal</span>

                        <?php if($persona->correo_personal): ?>

                            <a href="mailto:<?php echo e($persona->correo_personal); ?>">
                                <?php echo e($persona->correo_personal); ?>

                            </a>

                        <?php else: ?>

                            <strong>No registrado</strong>

                        <?php endif; ?>
                    </div>

                    <div class="portal-detail-item">
                        <span>Teléfono móvil</span>

                        <strong>
                            <?php echo e($persona->telefono_movil ?: 'No registrado'); ?>

                        </strong>

                        <?php if(
                            $persona->telefono_movil &&
                            $persona->telefono_movil_whatsapp
                        ): ?>
                            <small class="portal-detail-whatsapp">
                                <i class="bi bi-whatsapp"></i>
                                Disponible en WhatsApp
                            </small>
                        <?php endif; ?>
                    </div>

                    <div class="portal-detail-item">
                        <span>Teléfono fijo</span>
                        <strong><?php echo e($persona->telefono_fijo ?: 'No registrado'); ?></strong>
                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-detail-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-geo-alt"></i>
                    </div>

                    <div>
                        <h2>Residencia</h2>
                        <p>Ubicación actual de la persona.</p>
                    </div>

                </div>

                <div class="portal-detail-grid">

                    <div class="portal-detail-item">
                        <span>País</span>

                        <strong>
                            <?php echo e($persona->paisResidencia?->nombre
                                ?: 'No especificado'); ?>

                        </strong>
                    </div>

                    <div class="portal-detail-item">
                        <span>Departamento o estado</span>
                        <strong><?php echo e($persona->departamento_estado ?: 'No especificado'); ?></strong>
                    </div>

                    <div class="portal-detail-item">
                        <span>Ciudad o municipio</span>
                        <strong><?php echo e($persona->ciudad_municipio ?: 'No especificada'); ?></strong>
                    </div>

                    <div class="portal-detail-item portal-detail-item-full">
                        <span>Dirección</span>
                        <strong><?php echo e($persona->direccion ?: 'No registrada'); ?></strong>
                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-detail-card mb-0">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-folder2-open"></i>
                    </div>

                    <div>
                        <h2>Documentos adjuntos</h2>
                        <p>Archivos incorporados al expediente.</p>
                    </div>

                </div>

                <?php if($persona->documentos->isNotEmpty()): ?>

                    <div class="portal-document-list">

                        <?php $__currentLoopData = $persona->documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <article class="portal-document-item">

                                <span class="portal-document-icon">
                                    <i class="bi bi-file-earmark-text"></i>
                                </span>

                                <div>
                                    <strong>
                                        <?php echo e($documento->nombre_original); ?>

                                    </strong>

                                    <small>
                                        <?php echo e(str($documento->tipo_documento)
                                            ->replace('_', ' ')
                                            ->title()); ?>

                                        ·
                                        <?php echo e($documento->tamano_legible); ?>

                                    </small>
                                </div>

                                <?php if($documento->verificado): ?>

                                    <span class="portal-document-verified">
                                        <i class="bi bi-patch-check-fill"></i>
                                        Verificado
                                    </span>

                                <?php else: ?>

                                    <span class="portal-document-pending">
                                        Pendiente
                                    </span>

                                <?php endif; ?>

                            </article>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php else: ?>

                    <div class="portal-empty-state portal-empty-state-documents">

                        <div class="portal-empty-icon">
                            <i class="bi bi-folder-x"></i>
                        </div>

                        <h3>No hay documentos adjuntos</h3>

                        <p>
                            Los documentos personales podrán incorporarse
                            posteriormente al expediente.
                        </p>

                    </div>

                <?php endif; ?>

            </section>

        </div>

    </div>

    
    <div
        class="modal fade"
        id="changeStatusModal"
        tabindex="-1"
        aria-labelledby="changeStatusModalLabel"
        aria-hidden="true"
    >
        <div class="modal-dialog modal-dialog-centered">

            <div class="modal-content portal-modal">
 
                <form
                    action="<?php echo e(route('portal.personas.cambiar-estado', $persona)); ?>"
                    method="POST"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <div class="modal-header">

                        <div>
                            <span class="portal-modal-eyebrow">
                                Confirmación
                            </span>

                            <h2
                                class="modal-title"
                                id="changeStatusModalLabel"
                            >
                                <?php echo e($persona->estado === 'activo'
                                    ? 'Desactivar persona'
                                    : 'Activar persona'); ?>

                            </h2>
                        </div>

                        <button
                            type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Cerrar"
                        ></button>

                    </div>

                    <div class="modal-body">

                        <div class="portal-modal-warning-icon">
                            <i class="bi bi-person-gear"></i>
                        </div>

                        <p class="mb-0">

                            <?php if($persona->estado === 'activo'): ?>

                                ¿Desea desactivar a
                                <strong><?php echo e($persona->nombre_completo); ?></strong>?
                                Su información histórica se conservará.

                            <?php else: ?>

                                ¿Desea activar nuevamente a
                                <strong><?php echo e($persona->nombre_completo); ?></strong>?

                            <?php endif; ?>

                        </p>

                    </div>

                    <div class="modal-footer">

                        <button
                            type="button"
                            class="btn portal-btn-secondary"
                            data-bs-dismiss="modal"
                        >
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            class="btn
                                <?php echo e($persona->estado === 'activo'
                                    ? 'portal-btn-danger'
                                    : 'portal-btn-primary'); ?>"
                        >
                            <?php echo e($persona->estado === 'activo'
                                ? 'Desactivar'
                                : 'Activar'); ?>

                        </button>

                    </div>

                </form>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/personas/show.blade.php ENDPATH**/ ?>