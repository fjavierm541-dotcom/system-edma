

<?php $__env->startSection('title', 'Nuevo empleado | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Nuevo empleado'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión de recursos humanos
            </span>

            <h1>Registrar empleado</h1>

            <p>
                Seleccione una persona existente y complete la
                información correspondiente a su expediente laboral.
            </p>
        </div>

        <div class="portal-page-actions">

            <a
                href="<?php echo e(route('portal.empleados.index')); ?>"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver al listado
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form
        action="<?php echo e(route('portal.empleados.store')); ?>"
        method="POST"
        id="empleadoForm"
        novalidate
    >
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('portal.empleados.partials._form', [
            'empleado' => null,
            'modoEdicion' => false,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/empleados/create.blade.php ENDPATH**/ ?>