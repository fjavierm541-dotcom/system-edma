<footer class="edma-footer">
    <div class="edma-container">
        <div class="edma-footer__content">

            <p class="edma-footer__text">
                © <?php echo e(date('Y')); ?> Edumerican Academy Honduras.
                2026
            </p>

        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\system-edma\resources\views/components/website/footer.blade.php ENDPATH**/ ?>