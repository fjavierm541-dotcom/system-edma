

<?php $__env->startSection('title', 'Nuevo período | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Nuevo período'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión académica
            </span>

            <h1>Registrar período académico</h1>

            <p>
                Defina las fechas de matrícula y el desarrollo
                académico del nuevo período.
            </p>
        </div>

        <div class="portal-page-actions">

            <a
                href="<?php echo e(route('portal.periodos.index')); ?>"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form
        action="<?php echo e(route('portal.periodos.store')); ?>"
        method="POST"
        novalidate
    >
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('portal.periodos.partials._form', [
            'periodo' => null,
            'modoEdicion' => false,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/periodos/create.blade.php ENDPATH**/ ?>