<?php
    $valor = function (
        string $campo,
        mixed $predeterminado = null
    ) use ($persona) {
        return old(
            $campo,
            $persona?->{$campo} ?? $predeterminado
        );
    };
?>

<div class="row g-4">

    
    <div class="col-12 col-xl-9">

        
        <section class="portal-card portal-form-card">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-person-vcard"></i>
                </div>

                <div>
                    <h2>Datos personales</h2>

                    <p>
                        Información general de identificación de la persona.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <div class="row g-3">

                    <div class="col-12 col-md-6">

                        <label
                            for="primer_nombre"
                            class="form-label portal-form-label"
                        >
                            Primer nombre
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="text"
                            name="primer_nombre"
                            id="primer_nombre"
                            value="<?php echo e($valor('primer_nombre')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['primer_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="50"
                            autocomplete="given-name"
                            required
                        >

                        <?php $__errorArgs = ['primer_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="segundo_nombre"
                            class="form-label portal-form-label"
                        >
                            Segundo nombre
                        </label>

                        <input
                            type="text"
                            name="segundo_nombre"
                            id="segundo_nombre"
                            value="<?php echo e($valor('segundo_nombre')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['segundo_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="50"
                            autocomplete="additional-name"
                        >

                        <?php $__errorArgs = ['segundo_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="primer_apellido"
                            class="form-label portal-form-label"
                        >
                            Primer apellido
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="text"
                            name="primer_apellido"
                            id="primer_apellido"
                            value="<?php echo e($valor('primer_apellido')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['primer_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="50"
                            autocomplete="family-name"
                            required
                        >

                        <?php $__errorArgs = ['primer_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="segundo_apellido"
                            class="form-label portal-form-label"
                        >
                            Segundo apellido
                        </label>

                        <input
                            type="text"
                            name="segundo_apellido"
                            id="segundo_apellido"
                            value="<?php echo e($valor('segundo_apellido')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['segundo_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="50"
                        >

                        <?php $__errorArgs = ['segundo_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-4">

                        <label
                            for="fecha_nacimiento"
                            class="form-label portal-form-label"
                        >
                            Fecha de nacimiento
                        </label>

                        <input
                            type="date"
                            name="fecha_nacimiento"
                            id="fecha_nacimiento"
                            value="<?php echo e(old(
                                'fecha_nacimiento',
                                $persona?->fecha_nacimiento?->format('Y-m-d')
                            )); ?>"
                            max="<?php echo e(now()->format('Y-m-d')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['fecha_nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        >

                        <?php $__errorArgs = ['fecha_nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-4">

                        <label
                            for="sexo"
                            class="form-label portal-form-label"
                        >
                            Sexo
                        </label>

                        <select
                            name="sexo"
                            id="sexo"
                            class="form-select portal-form-control
                                <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        >
                            <option value="">
                                Seleccione una opción
                            </option>

                            <?php $__currentLoopData = $sexos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($clave); ?>"
                                    <?php if(
                                        $valor('sexo') === $clave
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($etiqueta); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-4">

                        <label
                            for="estado_civil"
                            class="form-label portal-form-label"
                        >
                            Estado civil
                        </label>

                        <select
                            name="estado_civil"
                            id="estado_civil"
                            class="form-select portal-form-control
                                <?php $__errorArgs = ['estado_civil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        >
                            <option value="">
                                Seleccione una opción
                            </option>

                            <?php $__currentLoopData = $estadosCiviles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($clave); ?>"
                                    <?php if(
                                        $valor('estado_civil') === $clave
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($etiqueta); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['estado_civil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                </div>

            </div>

        </section>

        
        <section class="portal-card portal-form-card">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-credit-card-2-front"></i>
                </div>

                <div>
                    <h2>Identificación</h2>

                    <p>
                        Documento oficial, nacionalidad y RTN.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <div class="row g-3">

                    <div class="col-12 col-md-5">

                        <label
                            for="tipo_documento"
                            class="form-label portal-form-label"
                        >
                            Tipo de documento
                        </label>

                        <select
                            name="tipo_documento"
                            id="tipo_documento"
                            class="form-select portal-form-control
                                <?php $__errorArgs = ['tipo_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        >
                            <option value="">
                                Sin documento
                            </option>

                            <?php $__currentLoopData = $tiposDocumento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($clave); ?>"
                                    <?php if(
                                        $valor('tipo_documento') === $clave
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($etiqueta); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['tipo_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-7">

                        <label
                            for="numero_documento"
                            class="form-label portal-form-label"
                        >
                            Número de documento
                        </label>

                        <input
                            type="text"
                            name="numero_documento"
                            id="numero_documento"
                            value="<?php echo e($valor('numero_documento')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['numero_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="50"
                            autocomplete="off"
                        >

                        <div
                            class="form-text portal-form-help"
                            id="documentoHelp"
                        >
                            Seleccione primero el tipo de documento.
                        </div>

                        <?php $__errorArgs = ['numero_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="nacionalidad"
                            class="form-label portal-form-label"
                        >
                            Nacionalidad
                        </label>

                        <input
                            type="text"
                            name="nacionalidad"
                            id="nacionalidad"
                            value="<?php echo e($valor('nacionalidad')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['nacionalidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="100"
                        >

                        <?php $__errorArgs = ['nacionalidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="rtn"
                            class="form-label portal-form-label"
                        >
                            RTN
                        </label>

                        <input
                            type="text"
                            name="rtn"
                            id="rtn"
                            value="<?php echo e($valor('rtn')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['rtn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="14"
                            minlength="14"
                            inputmode="numeric"
                            pattern="[0-9]{14}"
                            autocomplete="off"
                        >

                        <div class="form-text portal-form-help">
                            Debe contener exactamente 14 dígitos.
                        </div>

                        <?php $__errorArgs = ['rtn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                </div>

            </div>

        </section>

        
        <section class="portal-card portal-form-card">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-telephone"></i>
                </div>

                <div>
                    <h2>Información de contacto</h2>

                    <p>
                        Correo electrónico y números telefónicos.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <div class="row g-3">

                    <div class="col-12">

                        <label
                            for="correo_personal"
                            class="form-label portal-form-label"
                        >
                            Correo personal
                        </label>

                        <input
                            type="email"
                            name="correo_personal"
                            id="correo_personal"
                            value="<?php echo e($valor('correo_personal')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['correo_personal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="150"
                            autocomplete="email"
                        >

                        <?php $__errorArgs = ['correo_personal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="telefono_movil"
                            class="form-label portal-form-label"
                        >
                            Teléfono móvil
                        </label>

                        <input
                            type="tel"
                            name="telefono_movil"
                            id="telefono_movil"
                            value="<?php echo e($valor('telefono_movil')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['telefono_movil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="15"
                            inputmode="numeric"
                            pattern="[0-9]*"
                            autocomplete="tel"
                        >

                        <div class="form-text portal-form-help">
                            Debe contener entre 8 y 15 dígitos.
                        </div>

                        <?php $__errorArgs = ['telefono_movil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="telefono_fijo"
                            class="form-label portal-form-label"
                        >
                            Teléfono fijo
                        </label>

                        <input
                            type="tel"
                            name="telefono_fijo"
                            id="telefono_fijo"
                            value="<?php echo e($valor('telefono_fijo')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['telefono_fijo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="15"
                            inputmode="numeric"
                            pattern="[0-9]*"
                        >

                        <div class="form-text portal-form-help">
                            Debe contener entre 8 y 15 dígitos.
                        </div>

                        <?php $__errorArgs = ['telefono_fijo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12">

                        <div class="portal-form-check-card">

                            <div>
                                <i class="bi bi-whatsapp"></i>

                                <span>
                                    El número móvil también está disponible
                                    en WhatsApp
                                </span>
                            </div>

                            <div class="form-check form-switch m-0">

                                <input
                                    type="hidden"
                                    name="telefono_movil_whatsapp"
                                    value="0"
                                >

                                <input
                                    type="checkbox"
                                    name="telefono_movil_whatsapp"
                                    id="telefono_movil_whatsapp"
                                    value="1"
                                    class="form-check-input"
                                    <?php if(
                                        old(
                                            'telefono_movil_whatsapp',
                                            $persona?->telefono_movil_whatsapp
                                                ?? false
                                        )
                                    ): echo 'checked'; endif; ?>
                                    <?php if(
                                        blank(
                                            old(
                                                'telefono_movil',
                                                $persona?->telefono_movil
                                            )
                                        )
                                    ): echo 'disabled'; endif; ?>
                                >

                            </div>

                        </div>

                        <div class="portal-form-help">
                            Esta opción se habilitará cuando ingrese un
                            teléfono móvil.
                        </div>

                    </div>

                </div>

            </div>

        </section>

        
        <section class="portal-card portal-form-card mb-0">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-geo-alt"></i>
                </div>

                <div>
                    <h2>Residencia</h2>

                    <p>
                        Ubicación y dirección actual de la persona.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <div class="row g-3">

                    <div class="col-12 col-md-6">

                        <label
                            for="pais_residencia_id"
                            class="form-label portal-form-label"
                        >
                            País de residencia
                        </label>

                        <select
                            name="pais_residencia_id"
                            id="pais_residencia_id"
                            class="form-select portal-form-control
                                <?php $__errorArgs = ['pais_residencia_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        >
                            <option value="">
                                Seleccione un país
                            </option>

                            <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($pais->id); ?>"
                                    data-nationality="<?php echo e($pais->nacionalidad); ?>"
                                    <?php if(
                                        (string) $valor(
                                            'pais_residencia_id',
                                            $paisPredeterminado ?? null
                                        ) === (string) $pais->id
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($pais->nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['pais_residencia_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="departamento_estado"
                            class="form-label portal-form-label"
                        >
                            Departamento o estado
                        </label>

                        <input
                            type="text"
                            name="departamento_estado"
                            id="departamento_estado"
                            value="<?php echo e($valor('departamento_estado')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['departamento_estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="120"
                        >

                        <?php $__errorArgs = ['departamento_estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="ciudad_municipio"
                            class="form-label portal-form-label"
                        >
                            Ciudad o municipio
                        </label>

                        <input
                            type="text"
                            name="ciudad_municipio"
                            id="ciudad_municipio"
                            value="<?php echo e($valor('ciudad_municipio')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['ciudad_municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="120"
                        >

                        <?php $__errorArgs = ['ciudad_municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12">

                        <label
                            for="direccion"
                            class="form-label portal-form-label"
                        >
                            Dirección
                        </label>

                        <textarea
                            name="direccion"
                            id="direccion"
                            rows="3"
                            maxlength="500"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        ><?php echo e($valor('direccion')); ?></textarea>

                        <div class="form-text portal-form-help">
                            Máximo 500 caracteres.
                        </div>

                        <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                </div>

            </div>

        </section>

    </div>

    
    <div class="col-12 col-xl-3">

        <div class="portal-form-sidebar">

            
            <section class="portal-card portal-form-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-camera"></i>
                    </div>

                    <div>
                        <h2>Fotografía</h2>

                        <p>
                            Imagen opcional del perfil.
                        </p>
                    </div>

                </div>

                <div class="portal-form-section-body">

                    <div class="portal-photo-uploader">

                        <div class="portal-photo-preview">

                            <?php if($persona?->foto_perfil): ?>

                                <img
                                    src="<?php echo e(asset(
                                        'storage/' . $persona->foto_perfil
                                    )); ?>"
                                    alt="Fotografía actual"
                                    id="photoPreviewImage"
                                    data-original-src="<?php echo e(asset(
                                        'storage/' . $persona->foto_perfil
                                    )); ?>"
                                >

                            <?php else: ?>

                                <img
                                    src=""
                                    alt="Vista previa"
                                    id="photoPreviewImage"
                                    data-original-src=""
                                    hidden
                                >

                            <?php endif; ?>

                            <div
                                class="portal-photo-placeholder"
                                id="photoPlaceholder"
                                <?php if($persona?->foto_perfil): ?> hidden <?php endif; ?>
                            >
                                <i class="bi bi-person"></i>

                                <span>
                                    Sin fotografía
                                </span>
                            </div>

                        </div>

                        <label
                            for="foto_perfil"
                            class="btn portal-btn-secondary w-100"
                        >
                            <i class="bi bi-upload"></i>
                            Seleccionar imagen
                        </label>

                        <input
                            type="file"
                            name="foto_perfil"
                            id="foto_perfil"
                            class="d-none
                                <?php $__errorArgs = ['foto_perfil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                        >

                        <small class="portal-form-help text-center">
                            JPG, PNG o WEBP. Máximo 3 MB.
                        </small>

                        <?php $__errorArgs = ['foto_perfil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger small text-center">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <?php if(
                            $modoEdicion &&
                            $persona?->foto_perfil
                        ): ?>

                            <div class="form-check mt-2">

                                <input
                                    type="checkbox"
                                    name="eliminar_foto_perfil"
                                    id="eliminar_foto_perfil"
                                    value="1"
                                    class="form-check-input"
                                    <?php if(
                                        old('eliminar_foto_perfil')
                                    ): echo 'checked'; endif; ?>
                                >

                                <label
                                    for="eliminar_foto_perfil"
                                    class="form-check-label"
                                >
                                    Eliminar fotografía actual
                                </label>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-form-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-toggle-on"></i>
                    </div>

                    <div>
                        <h2>Estado</h2>

                        <p>
                            Disponibilidad del registro.
                        </p>
                    </div>

                </div>

                <div class="portal-form-section-body">

                    <label
                        for="estado"
                        class="form-label portal-form-label"
                    >
                        Estado de la persona
                    </label>

                    <select
                        name="estado"
                        id="estado"
                        class="form-select portal-form-control
                            <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    >
                        <option
                            value="activo"
                            <?php if(
                                $valor('estado', 'activo') === 'activo'
                            ): echo 'selected'; endif; ?>
                        >
                            Activa
                        </option>

                        <option
                            value="inactivo"
                            <?php if(
                                $valor('estado', 'activo') === 'inactivo'
                            ): echo 'selected'; endif; ?>
                        >
                            Inactiva
                        </option>
                    </select>

                    <div class="portal-form-help mt-2">
                        Las personas inactivas conservan toda su información
                        histórica.
                    </div>

                    <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

            </section>

            
            <section class="portal-card portal-form-actions-card">

                <div class="portal-form-actions">

                    <button
                        type="submit"
                        class="btn portal-btn-primary w-100"
                    >
                        <i class="bi bi-check2-circle"></i>

                        <?php echo e($modoEdicion
                            ? 'Guardar cambios'
                            : 'Registrar persona'); ?>

                    </button>

                    <a
                        href="<?php echo e($modoEdicion
                            ? route(
                                'portal.personas.show',
                                $persona
                            )
                            : route('portal.personas.index')); ?>"
                        class="btn portal-btn-secondary w-100"
                    >
                        Cancelar
                    </a>

                </div>

            </section>

        </div>

    </div>

</div>

<?php $__env->startPush('scripts'); ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const documentType = document.getElementById(
                'tipo_documento'
            );

            const documentNumber = document.getElementById(
                'numero_documento'
            );

            const documentHelp = document.getElementById(
                'documentoHelp'
            );

            const country = document.getElementById(
                'pais_residencia_id'
            );

            const nationality = document.getElementById(
                'nacionalidad'
            );

            const mobilePhone = document.getElementById(
                'telefono_movil'
            );

            const fixedPhone = document.getElementById(
                'telefono_fijo'
            );

            const whatsappSwitch = document.getElementById(
                'telefono_movil_whatsapp'
            );

            const rtn = document.getElementById('rtn');

            const photoInput = document.getElementById(
                'foto_perfil'
            );

            const photoImage = document.getElementById(
                'photoPreviewImage'
            );

            const photoPlaceholder = document.getElementById(
                'photoPlaceholder'
            );

            const removePhoto = document.getElementById(
                'eliminar_foto_perfil'
            );

            /*
            |--------------------------------------------------------------------------
            | Utilidades
            |--------------------------------------------------------------------------
            */

            const allowOnlyDigits = (
                element,
                maximumLength
            ) => {
                if (!element) {
                    return;
                }

                element.value = element.value
                    .replace(/\D/g, '')
                    .slice(0, maximumLength);
            };

            /*
            |--------------------------------------------------------------------------
            | Documento de identificación
            |--------------------------------------------------------------------------
            */

            const updateDocumentField = () => {
                if (
                    !documentType ||
                    !documentNumber ||
                    !documentHelp
                ) {
                    return;
                }

                const type = documentType.value;

                const isHonduranIdentity = [
                    'dni',
                    'identidad_menor',
                ].includes(type);

                const settings = {
                    dni: {
                        placeholder: 'Ejemplo: 0703199804911',
                        help: 'Debe contener exactamente 13 dígitos, sin guiones.',
                    },

                    identidad_menor: {
                        placeholder: 'Ejemplo: 0703199804911',
                        help: 'Debe contener exactamente 13 dígitos, sin guiones.',
                    },

                    pasaporte: {
                        placeholder: 'Ingrese el número de pasaporte',
                        help: 'Puede contener letras y números.',
                    },

                    otro: {
                        placeholder: 'Ingrese el número del documento',
                        help: 'Puede contener letras y números.',
                    },
                };

                const selected = settings[type];

                documentNumber.disabled = type === '';
                documentNumber.required = type !== '';

                documentNumber.inputMode = isHonduranIdentity
                    ? 'numeric'
                    : 'text';

                documentNumber.maxLength = isHonduranIdentity
                    ? 13
                    : 50;

                documentNumber.pattern = isHonduranIdentity
                    ? '[0-9]{13}'
                    : '';

                documentNumber.placeholder = selected
                    ? selected.placeholder
                    : 'Seleccione primero el tipo de documento';

                documentHelp.textContent = selected
                    ? selected.help
                    : 'Seleccione primero el tipo de documento';

                if (type === '') {
                    documentNumber.value = '';
                    return;
                }

                if (isHonduranIdentity) {
                    allowOnlyDigits(documentNumber, 13);
                }
            };

            /*
            |--------------------------------------------------------------------------
            | Nacionalidad sugerida
            |--------------------------------------------------------------------------
            */

            const updateNationality = () => {
                if (!country || !nationality) {
                    return;
                }

                const selectedOption =
                    country.options[country.selectedIndex];

                const selectedNationality =
                    selectedOption?.dataset.nationality ?? '';

                if (
                    nationality.value.trim() === '' &&
                    selectedNationality !== ''
                ) {
                    nationality.value = selectedNationality;
                }
            };

            /*
            |--------------------------------------------------------------------------
            | Disponibilidad de WhatsApp
            |--------------------------------------------------------------------------
            */

            const updateWhatsappAvailability = () => {
                if (!mobilePhone || !whatsappSwitch) {
                    return;
                }

                const hasMobilePhone =
                    mobilePhone.value.trim() !== '';

                whatsappSwitch.disabled = !hasMobilePhone;

                if (!hasMobilePhone) {
                    whatsappSwitch.checked = false;
                }
            };

            /*
            |--------------------------------------------------------------------------
            | Vista previa de fotografía
            |--------------------------------------------------------------------------
            */

            const showPhotoPlaceholder = () => {
                if (!photoImage || !photoPlaceholder) {
                    return;
                }

                photoImage.hidden = true;
                photoPlaceholder.hidden = false;
            };

            const showPhotoImage = source => {
                if (
                    !photoImage ||
                    !photoPlaceholder ||
                    !source
                ) {
                    return;
                }

                photoImage.src = source;
                photoImage.hidden = false;
                photoPlaceholder.hidden = true;
            };

            const previewPhoto = event => {
                const file = event.target.files?.[0];

                if (!file) {
                    return;
                }

                if (!file.type.startsWith('image/')) {
                    event.target.value = '';

                    alert(
                        'El archivo seleccionado debe ser una imagen.'
                    );

                    return;
                }

                const maximumSize = 3 * 1024 * 1024;

                if (file.size > maximumSize) {
                    event.target.value = '';

                    alert(
                        'La fotografía no puede superar los 3 MB.'
                    );

                    return;
                }

                const reader = new FileReader();

                reader.addEventListener('load', () => {
                    showPhotoImage(reader.result);

                    if (removePhoto) {
                        removePhoto.checked = false;
                    }
                });

                reader.readAsDataURL(file);
            };

            const updatePhotoRemoval = () => {
                if (!removePhoto || !photoImage) {
                    return;
                }

                if (removePhoto.checked) {
                    if (photoInput) {
                        photoInput.value = '';
                    }

                    showPhotoPlaceholder();

                    return;
                }

                const originalSource =
                    photoImage.dataset.originalSrc ?? '';

                if (originalSource !== '') {
                    showPhotoImage(originalSource);
                }
            };

            /*
            |--------------------------------------------------------------------------
            | Eventos
            |--------------------------------------------------------------------------
            */

            documentType?.addEventListener(
                'change',
                () => {
                    updateDocumentField();

                    if (
                        [
                            'dni',
                            'identidad_menor',
                        ].includes(documentType.value)
                    ) {
                        allowOnlyDigits(
                            documentNumber,
                            13
                        );
                    }
                }
            );

            documentNumber?.addEventListener(
                'input',
                () => {
                    const type =
                        documentType?.value ?? '';

                    if (
                        [
                            'dni',
                            'identidad_menor',
                        ].includes(type)
                    ) {
                        allowOnlyDigits(
                            documentNumber,
                            13
                        );
                    }
                }
            );

            rtn?.addEventListener(
                'input',
                () => {
                    allowOnlyDigits(rtn, 14);
                }
            );

            mobilePhone?.addEventListener(
                'input',
                () => {
                    allowOnlyDigits(
                        mobilePhone,
                        15
                    );

                    updateWhatsappAvailability();
                }
            );

            fixedPhone?.addEventListener(
                'input',
                () => {
                    allowOnlyDigits(
                        fixedPhone,
                        15
                    );
                }
            );

            country?.addEventListener(
                'change',
                updateNationality
            );

            photoInput?.addEventListener(
                'change',
                previewPhoto
            );

            removePhoto?.addEventListener(
                'change',
                updatePhotoRemoval
            );

            /*
            |--------------------------------------------------------------------------
            | Estado inicial
            |--------------------------------------------------------------------------
            */

            updateDocumentField();
            updateWhatsappAvailability();

            if (removePhoto?.checked) {
                updatePhotoRemoval();
            }
        });
    </script>

<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/personas/partials/_form.blade.php ENDPATH**/ ?>