

<?php $__env->startSection('title', $nivel->nombre . ' | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Nivel académico'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión académica
            </span>

            <h1>
                Nivel <?php echo e($nivel->nombre); ?>

            </h1>

            <p>
                Consulte la configuración académica y los
                grupos asociados a este nivel.
            </p>
        </div>

        <div class="portal-page-actions portal-page-actions-group">

            <a
                href="<?php echo e(route('portal.niveles.index')); ?>"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver
            </a>

            <a
                href="<?php echo e(route(
                    'portal.niveles.edit',
                    $nivel
                )); ?>"
                class="btn portal-btn-primary"
            >
                <i class="bi bi-pencil-square"></i>
                Editar nivel
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row g-4">

        
        <div class="col-12 col-xl-4">

            <section class="portal-card portal-profile-card">

                <div class="portal-profile-cover"></div>

                <div class="portal-profile-content">

                    <div class="portal-profile-photo">

                        <span>
                            <?php echo e($nivel->nombre); ?>

                        </span>

                    </div>

                    <h2>
                        Nivel <?php echo e($nivel->nombre); ?>

                    </h2>

                    <span class="portal-employee-code mt-2">
                        <?php echo e($nivel->codigo); ?>

                    </span>

                    <div class="mt-3">

                        <?php if($nivel->estado === 'activo'): ?>

                            <span class="portal-status-badge portal-status-active">
                                <span></span>
                                Nivel activo
                            </span>

                        <?php else: ?>

                            <span class="portal-status-badge portal-status-inactive">
                                <span></span>
                                Nivel inactivo
                            </span>

                        <?php endif; ?>

                    </div>

                </div>

                <div class="portal-profile-summary">

                    <div>
                        <span>Duración</span>

                        <strong>
                            <?php echo e($nivel->duracion_semanas); ?>

                            semanas
                        </strong>
                    </div>

                    <div>
                        <span>Nota mínima</span>

                        <strong>
                            <?php echo e($nivel->nota_minima_aprobacion !== null
                                ? number_format(
                                    (float) $nivel->nota_minima_aprobacion,
                                    0
                                ) . '/100'
                                : 'No definida'); ?>

                        </strong>
                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-profile-actions-card">

                <div class="portal-card-header">

                    <div>
                        <h2>Acciones</h2>
                        <p>Operaciones disponibles.</p>
                    </div>

                </div>

                <div class="portal-profile-actions">

                    <a
                        href="<?php echo e(route(
                            'portal.niveles.edit',
                            $nivel
                        )); ?>"
                        class="portal-profile-action"
                    >
                        <span>
                            <i class="bi bi-pencil-square"></i>
                        </span>

                        <div>
                            <strong>Editar nivel</strong>
                            <small>
                                Actualizar su configuración
                            </small>
                        </div>

                        <i class="bi bi-chevron-right"></i>
                    </a>

                    <a
                        href="<?php echo e(route(
                            'portal.programas.show',
                            $nivel->programa
                        )); ?>"
                        class="portal-profile-action"
                    >
                        <span>
                            <i class="bi bi-journal-bookmark"></i>
                        </span>

                        <div>
                            <strong>Ver programa</strong>

                            <small>
                                <?php echo e($nivel->programa?->nombre); ?>

                            </small>
                        </div>

                        <i class="bi bi-chevron-right"></i>
                    </a>

                    <button
                        type="button"
                        class="portal-profile-action portal-profile-action-button"
                        data-bs-toggle="modal"
                        data-bs-target="#changeLevelStatusModal"
                    >
                        <span>
                            <i class="bi bi-toggle-on"></i>
                        </span>

                        <div>
                            <strong>
                                <?php echo e($nivel->estado === 'activo'
                                    ? 'Desactivar nivel'
                                    : 'Activar nivel'); ?>

                            </strong>

                            <small>
                                <?php echo e($nivel->estado === 'activo'
                                    ? 'Dejará de estar disponible para nuevos procesos'
                                    : 'Volverá a estar disponible'); ?>

                            </small>
                        </div>

                        <i class="bi bi-chevron-right"></i>
                    </button>

                </div>

            </section>

        </div>

        
        <div class="col-12 col-xl-8">

            
            <section class="portal-card portal-detail-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-info-circle"></i>
                    </div>

                    <div>
                        <h2>Información del nivel</h2>

                        <p>
                            Configuración académica utilizada
                            para este nivel.
                        </p>
                    </div>

                </div>

                <div class="portal-detail-grid">

                    <div class="portal-detail-item">

                        <span>Código</span>

                        <strong>
                            <?php echo e($nivel->codigo); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Nombre</span>

                        <strong>
                            <?php echo e($nivel->nombre); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Programa</span>

                        <strong>
                            <?php echo e($nivel->programa?->nombre
                                ?: 'No disponible'); ?>

                        </strong>

                        <?php if($nivel->programa): ?>

                            <small>
                                <?php echo e($nivel->programa->codigo); ?>

                            </small>

                        <?php endif; ?>

                    </div>

                    <div class="portal-detail-item">

                        <span>Orden académico</span>

                        <strong>
                            <?php echo e($nivel->orden); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Duración</span>

                        <strong>
                            <?php echo e($nivel->duracion_semanas); ?>

                            semanas
                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Nota mínima de aprobación</span>

                        <strong>
                            <?php echo e($nivel->nota_minima_aprobacion !== null
                                ? number_format(
                                    (float) $nivel->nota_minima_aprobacion,
                                    2
                                ) . ' / 100'
                                : 'No definida'); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Estado</span>

                        <strong>
                            <?php echo e(str($nivel->estado)->title()); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item">

                        <span>Grupos registrados</span>

                        <strong>
                            <?php echo e($nivel->grupos->count()); ?>

                        </strong>

                    </div>

                    <div class="portal-detail-item portal-detail-item-full">

                        <span>Descripción</span>

                        <strong>
                            <?php echo e($nivel->descripcion
                                ?: 'Sin descripción registrada'); ?>

                        </strong>

                    </div>

                </div>

            </section>

            
            <section class="portal-card portal-detail-card mb-0">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-people"></i>
                    </div>

                    <div>
                        <h2>Grupos</h2>

                        <p>
                            Grupos académicos registrados
                            para este nivel.
                        </p>
                    </div>

                </div>

                <?php if($nivel->grupos->isNotEmpty()): ?>

                    <div class="portal-academic-list">

                        <?php $__currentLoopData = $nivel->grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <article class="portal-academic-item">

                                <div class="portal-academic-icon">
                                    <i class="bi bi-people"></i>
                                </div>

                                <div class="portal-academic-info">

                                    <strong>
                                        <?php echo e($grupo->nombre); ?>

                                    </strong>

                                    <span>
                                        <?php echo e($grupo->codigo); ?>

                                    </span>

                                    <small>
                                        <?php echo e(str($grupo->modalidad)->title()); ?>

                                        · Cupo máximo:
                                        <?php echo e($grupo->cupo_maximo); ?>

                                    </small>

                                </div>

                                <?php if($grupo->estado === 'activo'): ?>

                                    <span class="portal-status-badge portal-status-active">
                                        <span></span>
                                        Activo
                                    </span>

                                <?php else: ?>

                                    <span class="portal-status-badge portal-status-inactive">
                                        <span></span>
                                        <?php echo e(str($grupo->estado)->title()); ?>

                                    </span>

                                <?php endif; ?>

                            </article>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php else: ?>

                    <div class="portal-empty-state portal-empty-state-documents">

                        <div class="portal-empty-icon">
                            <i class="bi bi-people"></i>
                        </div>

                        <h3>No hay grupos registrados</h3>

                        <p>
                            Cuando se creen grupos para este nivel,
                            aparecerán en esta sección.
                        </p>

                    </div>

                <?php endif; ?>

            </section>

        </div>

    </div>

    
    <div
        class="modal fade"
        id="changeLevelStatusModal"
        tabindex="-1"
        aria-labelledby="changeLevelStatusModalLabel"
        aria-hidden="true"
    >
        <div class="modal-dialog modal-dialog-centered">

            <div class="modal-content portal-modal">

                <form
                    action="<?php echo e(route(
                        'portal.niveles.cambiar-estado',
                        $nivel
                    )); ?>"
                    method="POST"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <div class="modal-header">

                        <div>
                            <span class="portal-modal-eyebrow">
                                Confirmación
                            </span>

                            <h2
                                class="modal-title"
                                id="changeLevelStatusModalLabel"
                            >
                                <?php echo e($nivel->estado === 'activo'
                                    ? 'Desactivar nivel'
                                    : 'Activar nivel'); ?>

                            </h2>
                        </div>

                        <button
                            type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Cerrar"
                        ></button>

                    </div>

                    <div class="modal-body">

                        <div class="portal-modal-warning-icon">
                            <i class="bi bi-layers"></i>
                        </div>

                        <p class="mb-0">

                            <?php if($nivel->estado === 'activo'): ?>

                                ¿Desea desactivar el nivel
                                <strong><?php echo e($nivel->nombre); ?></strong>?
                                La información registrada se conservará.

                            <?php else: ?>

                                ¿Desea activar nuevamente el nivel
                                <strong><?php echo e($nivel->nombre); ?></strong>?

                            <?php endif; ?>

                        </p>

                    </div>

                    <div class="modal-footer">

                        <button
                            type="button"
                            class="btn portal-btn-secondary"
                            data-bs-dismiss="modal"
                        >
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            class="btn
                                <?php echo e($nivel->estado === 'activo'
                                    ? 'portal-btn-danger'
                                    : 'portal-btn-primary'); ?>"
                        >
                            <?php echo e($nivel->estado === 'activo'
                                ? 'Desactivar'
                                : 'Activar'); ?>

                        </button>

                    </div>

                </form>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/niveles/show.blade.php ENDPATH**/ ?>