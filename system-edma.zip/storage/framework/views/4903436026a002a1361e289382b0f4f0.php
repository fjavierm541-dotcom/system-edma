

<?php $__env->startSection('content'); ?>

    <div class="container py-5">

        <h1>
            Solicitud recibida
        </h1>

        <p>
            Su solicitud fue enviada correctamente.
        </p>

        <p>
            Código de solicitud:
            <strong>
                <?php echo e($codigoSolicitud); ?>

            </strong>
        </p>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/inscripciones/exito.blade.php ENDPATH**/ ?>