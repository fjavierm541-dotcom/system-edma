

<?php $__env->startSection('title', 'Empleados | Portal EDMA'); ?>

<?php $__env->startSection('page-title', 'Empleados'); ?>

<?php $__env->startSection('page-header'); ?>

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión de recursos humanos
            </span>

            <h1>Expedientes de empleados</h1>

            <p>
                Consulte y administre la información laboral
                del personal registrado en Edumerican Academy Honduras.
            </p>
        </div>

        <div class="portal-page-actions">

            <a
                href="<?php echo e(route('portal.empleados.create')); ?>"
                class="btn portal-btn-primary"
            >
                <i class="bi bi-person-badge"></i>
                Nuevo empleado
            </a>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
    <section class="portal-summary-grid">

        <article class="portal-summary-card">

            <div class="portal-summary-icon">
                <i class="bi bi-briefcase"></i>
            </div>

            <div>
                <span>Total de empleados</span>

                <strong>
                    <?php echo e(number_format($resumen['total'])); ?>

                </strong>

                <small>
                    Expedientes laborales
                </small>
            </div>

        </article>

        <article class="portal-summary-card">

            <div class="portal-summary-icon portal-summary-icon-success">
                <i class="bi bi-person-check"></i>
            </div>

            <div>
                <span>Empleados activos</span>

                <strong>
                    <?php echo e(number_format($resumen['activos'])); ?>

                </strong>

                <small>
                    Personal actualmente activo
                </small>
            </div>

        </article>

        <article class="portal-summary-card">

            <div class="portal-summary-icon portal-summary-icon-muted">
                <i class="bi bi-person-dash"></i>
            </div>

            <div>
                <span>Empleados inactivos</span>

                <strong>
                    <?php echo e(number_format($resumen['inactivos'])); ?>

                </strong>

                <small>
                    Conservan su historial laboral
                </small>
            </div>

        </article>

    </section>

    
    <section class="portal-card">

        <div class="portal-card-header portal-card-header-responsive">

            <div>
                <h2>Directorio de empleados</h2>

                <p>
                    Busque por código, nombre, documento, correo,
                    teléfono o institución laboral.
                </p>
            </div>

            <span class="portal-results-count">
                <?php echo e($empleados->total()); ?>


                <?php echo e($empleados->total() === 1
                    ? 'resultado'
                    : 'resultados'); ?>

            </span>

        </div>

        
        <div class="portal-filter-area">

            <form
                action="<?php echo e(route('portal.empleados.index')); ?>"
                method="GET"
                class="portal-filter-form"
            >

                <div class="portal-search-field">

                    <i class="bi bi-search"></i>

                    <input
                        type="search"
                        name="buscar"
                        value="<?php echo e($termino); ?>"
                        class="form-control"
                        placeholder="Código, nombre, DNI, correo..."
                        aria-label="Buscar empleados"
                    >

                </div>

                <div class="portal-filter-select">

                    <label
                        for="estado"
                        class="visually-hidden"
                    >
                        Estado del empleado
                    </label>

                    <select
                        name="estado"
                        id="estado"
                        class="form-select"
                    >
                        <option value="">
                            Todos los estados
                        </option>

                        <option
                            value="activo"
                            <?php if(
                                $estadoSeleccionado === 'activo'
                            ): echo 'selected'; endif; ?>
                        >
                            Activos
                        </option>

                        <option
                            value="inactivo"
                            <?php if(
                                $estadoSeleccionado === 'inactivo'
                            ): echo 'selected'; endif; ?>
                        >
                            Inactivos
                        </option>
                    </select>

                </div>

                <button
                    type="submit"
                    class="btn portal-btn-primary"
                >
                    <i class="bi bi-funnel"></i>
                    Aplicar
                </button>

                <?php if(
                    $termino !== '' ||
                    $estadoSeleccionado
                ): ?>

                    <a
                        href="<?php echo e(route('portal.empleados.index')); ?>"
                        class="btn portal-btn-secondary"
                    >
                        <i class="bi bi-x-circle"></i>
                        Limpiar
                    </a>

                <?php endif; ?>

            </form>

        </div>

        <?php if($empleados->isNotEmpty()): ?>

            <div class="portal-table-responsive">

                <table class="table portal-table portal-employee-table align-middle mb-0">

                    <thead>
                        <tr>
                            <th>Empleado</th>
                            <th>Código</th>
                            <th>Documento</th>
                            <th>Ingreso</th>
                            <th>Situación laboral</th>
                            <th>Rol</th>
                            <th>Estado</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                                $persona = $empleado->persona;
                            ?>

                            <tr>

                                
                                <td>

                                    <div class="portal-person-cell">

                                        <?php if($persona?->foto_perfil): ?>

                                            <img
                                                src="<?php echo e(asset(
                                                    'storage/' .
                                                    $persona->foto_perfil
                                                )); ?>"
                                                alt="Fotografía de <?php echo e($persona->nombre_completo); ?>"
                                                class="portal-person-avatar"
                                            >

                                        <?php else: ?>

                                            <span class="portal-person-avatar portal-person-avatar-placeholder">
                                                <?php echo e($persona?->iniciales ?: 'EM'); ?>

                                            </span>

                                        <?php endif; ?>

                                        <div class="portal-person-data">

                                            <a
                                                href="<?php echo e(route(
                                                    'portal.empleados.show',
                                                    $empleado
                                                )); ?>"
                                                class="portal-person-name"
                                            >
                                                <?php echo e($persona?->nombre_completo
                                                    ?: 'Persona no disponible'); ?>

                                            </a>

                                            <?php if($persona?->correo_personal): ?>

                                                <small class="portal-text-ellipsis">
                                                    <?php echo e($persona->correo_personal); ?>

                                                </small>

                                            <?php elseif($persona?->telefono_movil): ?>

                                                <small>
                                                    <?php echo e($persona->telefono_movil); ?>

                                                </small>

                                            <?php else: ?>

                                                <small>
                                                    Sin información de contacto
                                                </small>

                                            <?php endif; ?>

                                        </div>

                                    </div>

                                </td>

                                
                                <td>

                                    <span class="portal-employee-code">
                                        <?php echo e($empleado->codigo_empleado); ?>

                                    </span>

                                </td>

                                
                                <td>

                                    <?php if($persona?->numero_documento): ?>

                                        <div class="portal-table-primary">
                                            <?php echo e($persona->numero_documento); ?>

                                        </div>

                                        <small class="portal-table-secondary">
                                            <?php echo e(str($persona->tipo_documento)
                                                ->replace('_', ' ')
                                                ->title()); ?>

                                        </small>

                                    <?php else: ?>

                                        <span class="portal-no-data">
                                            Sin documento
                                        </span>

                                    <?php endif; ?>

                                </td>

                                
                                <td>

                                    <div class="portal-table-primary">
                                        <?php echo e($empleado->fecha_ingreso
                                            ? $empleado->fecha_ingreso
                                                ->translatedFormat('d M Y')
                                            : 'No registrada'); ?>

                                    </div>

                                    <?php if($empleado->fecha_ingreso): ?>

                                        <small class="portal-table-secondary">
                                            <?php echo e($empleado->fecha_ingreso
                                                ->diffForHumans()); ?>

                                        </small>

                                    <?php endif; ?>

                                </td>

                                
                                <td>

                                    <?php if($empleado->institucion_laboral_actual): ?>

                                        <div class="portal-table-primary">
                                            <?php echo e($empleado->institucion_laboral_actual); ?>

                                        </div>

                                        <?php if($empleado->horario_laboral_actual): ?>

                                            <small class="portal-table-secondary">
                                                <?php echo e($empleado->horario_laboral_actual); ?>

                                            </small>

                                        <?php endif; ?>

                                    <?php else: ?>

                                        <span class="portal-no-data">
                                            No especificada
                                        </span>

                                    <?php endif; ?>

                                </td>

                                
                                <td>

                                    <?php if($empleado->docente): ?>

                                        <span class="portal-role-badge portal-role-badge-teacher">
                                            <i class="bi bi-easel"></i>
                                            Docente
                                        </span>

                                    <?php else: ?>

                                        <span class="portal-role-badge">
                                            <i class="bi bi-briefcase"></i>
                                            Empleado
                                        </span>

                                    <?php endif; ?>

                                </td>

                                
                                <td>

                                    <?php if($empleado->estado === 'activo'): ?>

                                        <span class="portal-status-badge portal-status-active">
                                            <span></span>
                                            Activo
                                        </span>

                                    <?php else: ?>

                                        <span class="portal-status-badge portal-status-inactive">
                                            <span></span>
                                            Inactivo
                                        </span>

                                    <?php endif; ?>

                                </td>

                                
                                <td class="text-end">

                                    <div class="dropdown">

                                        <button
                                            type="button"
                                            class="portal-table-action"
                                            data-bs-toggle="dropdown"
                                            aria-expanded="false"
                                            aria-label="Opciones del empleado"
                                        >
                                            <i class="bi bi-three-dots-vertical"></i>
                                        </button>

                                        <ul class="dropdown-menu dropdown-menu-end portal-actions-menu">

                                            <li>
                                                <a
                                                    href="<?php echo e(route(
                                                        'portal.empleados.show',
                                                        $empleado
                                                    )); ?>"
                                                    class="dropdown-item"
                                                >
                                                    <i class="bi bi-eye"></i>
                                                    Ver expediente
                                                </a>
                                            </li>

                                            <li>
                                                <a
                                                    href="<?php echo e(route(
                                                        'portal.empleados.edit',
                                                        $empleado
                                                    )); ?>"
                                                    class="dropdown-item"
                                                >
                                                    <i class="bi bi-pencil-square"></i>
                                                    Editar información
                                                </a>
                                            </li>

                                            <?php if($persona): ?>

                                                <li>
                                                    <a
                                                        href="<?php echo e(route(
                                                            'portal.personas.show',
                                                            $persona
                                                        )); ?>"
                                                        class="dropdown-item"
                                                    >
                                                        <i class="bi bi-person-vcard"></i>
                                                        Ver datos personales
                                                    </a>
                                                </li>

                                            <?php endif; ?>

                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>

                                            <li>

                                                <button
                                                    type="button"
                                                    class="dropdown-item
                                                        <?php echo e($empleado->estado === 'activo'
                                                            ? 'text-warning-emphasis'
                                                            : 'text-success'); ?>"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#changeEmployeeStatusModal"
                                                    data-employee-name="<?php echo e($persona?->nombre_completo); ?>"
                                                    data-employee-status="<?php echo e($empleado->estado); ?>"
                                                    data-action="<?php echo e(route(
                                                        'portal.empleados.cambiar-estado',
                                                        $empleado
                                                    )); ?>"
                                                >
                                                    <i class="bi
                                                        <?php echo e($empleado->estado === 'activo'
                                                            ? 'bi-person-dash'
                                                            : 'bi-person-check'); ?>">
                                                    </i>

                                                    <?php echo e($empleado->estado === 'activo'
                                                        ? 'Desactivar empleado'
                                                        : 'Activar empleado'); ?>

                                                </button>

                                            </li>

                                        </ul>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

            <div class="portal-table-footer">

                <div class="portal-pagination-summary">
                    Mostrando

                    <strong>
                        <?php echo e($empleados->firstItem()); ?>

                    </strong>

                    a

                    <strong>
                        <?php echo e($empleados->lastItem()); ?>

                    </strong>

                    de

                    <strong>
                        <?php echo e($empleados->total()); ?>

                    </strong>

                    registros
                </div>

                <div>
                    <?php echo e($empleados->links()); ?>

                </div>

            </div>

        <?php else: ?>

            <div class="portal-empty-state portal-empty-state-large">

                <div class="portal-empty-icon">
                    <i class="bi bi-briefcase"></i>
                </div>

                <?php if(
                    $termino !== '' ||
                    $estadoSeleccionado
                ): ?>

                    <h3>No se encontraron empleados</h3>

                    <p>
                        No existen expedientes laborales que coincidan
                        con los criterios seleccionados.
                    </p>

                    <a
                        href="<?php echo e(route('portal.empleados.index')); ?>"
                        class="btn portal-btn-secondary mt-3"
                    >
                        Limpiar filtros
                    </a>

                <?php else: ?>

                    <h3>Todavía no hay empleados registrados</h3>

                    <p>
                        Seleccione una persona existente para crear
                        su expediente laboral.
                    </p>

                    <a
                        href="<?php echo e(route('portal.empleados.create')); ?>"
                        class="btn portal-btn-primary mt-3"
                    >
                        <i class="bi bi-person-badge"></i>
                        Registrar empleado
                    </a>

                <?php endif; ?>

            </div>

        <?php endif; ?>

    </section>

    
    <div
        class="modal fade"
        id="changeEmployeeStatusModal"
        tabindex="-1"
        aria-labelledby="changeEmployeeStatusModalLabel"
        aria-hidden="true"
    >
        <div class="modal-dialog modal-dialog-centered">

            <div class="modal-content portal-modal">

                <form
                    method="POST"
                    id="changeEmployeeStatusForm"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <div class="modal-header">

                        <div>
                            <span class="portal-modal-eyebrow">
                                Confirmación
                            </span>

                            <h2
                                class="modal-title"
                                id="changeEmployeeStatusModalLabel"
                            >
                                Cambiar estado
                            </h2>
                        </div>

                        <button
                            type="button"
                            class="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Cerrar"
                        ></button>

                    </div>

                    <div class="modal-body">

                        <div class="portal-modal-warning-icon">
                            <i class="bi bi-person-gear"></i>
                        </div>

                        <p
                            id="changeEmployeeStatusMessage"
                            class="mb-0"
                        ></p>

                    </div>

                    <div class="modal-footer">

                        <button
                            type="button"
                            class="btn portal-btn-secondary"
                            data-bs-dismiss="modal"
                        >
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            class="btn portal-btn-primary"
                            id="changeEmployeeStatusSubmit"
                        >
                            Confirmar
                        </button>

                    </div>

                </form>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const modal = document.getElementById(
                'changeEmployeeStatusModal'
            );

            const form = document.getElementById(
                'changeEmployeeStatusForm'
            );

            const message = document.getElementById(
                'changeEmployeeStatusMessage'
            );

            const submitButton = document.getElementById(
                'changeEmployeeStatusSubmit'
            );

            if (
                !modal ||
                !form ||
                !message ||
                !submitButton
            ) {
                return;
            }

            modal.addEventListener('show.bs.modal', event => {
                const button = event.relatedTarget;

                const employeeName =
                    button.dataset.employeeName ||
                    'este empleado';

                const employeeStatus =
                    button.dataset.employeeStatus;

                const action =
                    button.dataset.action;

                const willDeactivate =
                    employeeStatus === 'activo';

                form.action = action;

                message.textContent = willDeactivate
                    ? `¿Desea desactivar a ${employeeName}? Su historial laboral se conservará.`
                    : `¿Desea activar nuevamente a ${employeeName}?`;

                submitButton.textContent = willDeactivate
                    ? 'Desactivar'
                    : 'Activar';

                submitButton.classList.toggle(
                    'portal-btn-danger',
                    willDeactivate
                );

                submitButton.classList.toggle(
                    'portal-btn-primary',
                    !willDeactivate
                );
            });
        });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/empleados/index.blade.php ENDPATH**/ ?>