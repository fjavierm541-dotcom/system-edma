<?php
    $empleadoActual = $modoEdicion
        ? $docente->empleado
        : $empleadoSeleccionado;

    $empleadoIdActual = old(
        'empleado_id',
        $modoEdicion
            ? $docente->empleado_id
            : $empleadoSeleccionado?->id
    );

    $fechaInicioActual = old(
        'fecha_inicio_docencia',
        $docente?->fecha_inicio_docencia?->format('Y-m-d')
            ?? now()->format('Y-m-d')
    );

    $estadoActual = old(
        'estado',
        $docente?->estado ?? 'activo'
    );
?>

<div class="row g-4">

    <div class="col-12 col-xl-8">

        
        <section class="portal-card portal-form-card">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-briefcase"></i>
                </div>

                <div>
                    <h2>Empleado asociado</h2>

                    <p>
                        El perfil docente se vincula a un empleado existente.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <?php if($modoEdicion): ?>

                    <div class="portal-student-person-card">

                        <div class="portal-student-person-avatar">

                            <?php if($empleadoActual?->persona?->foto_perfil): ?>

                                <img
                                    src="<?php echo e(asset(
                                        'storage/' .
                                        $empleadoActual->persona->foto_perfil
                                    )); ?>"
                                    alt="Fotografía de <?php echo e($empleadoActual->persona->nombre_completo); ?>"
                                >

                            <?php else: ?>

                                <span>
                                    <?php echo e($empleadoActual?->persona?->iniciales ?: 'DO'); ?>

                                </span>

                            <?php endif; ?>

                        </div>

                        <div class="portal-student-person-info">

                            <span class="portal-student-person-label">
                                Empleado vinculado
                            </span>

                            <h3>
                                <?php echo e($empleadoActual->persona->nombre_completo); ?>

                            </h3>

                            <div class="portal-student-person-meta">

                                <span>
                                    <i class="bi bi-upc-scan"></i>
                                    <?php echo e($empleadoActual->codigo_empleado); ?>

                                </span>

                                <?php if($empleadoActual->persona->numero_documento): ?>

                                    <span>
                                        <i class="bi bi-credit-card-2-front"></i>
                                        <?php echo e($empleadoActual->persona->numero_documento); ?>

                                    </span>

                                <?php endif; ?>

                                <?php if($empleadoActual->persona->correo_personal): ?>

                                    <span>
                                        <i class="bi bi-envelope"></i>
                                        <?php echo e($empleadoActual->persona->correo_personal); ?>

                                    </span>

                                <?php endif; ?>

                            </div>

                        </div>

                        <a
                            href="<?php echo e(route(
                                'portal.empleados.show',
                                $empleadoActual
                            )); ?>"
                            class="btn portal-btn-secondary btn-sm"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            <i class="bi bi-box-arrow-up-right"></i>
                            Ver empleado
                        </a>

                    </div>

                    <div class="portal-form-help mt-3">
                        El empleado vinculado y el código docente
                        no pueden cambiarse después de crear el perfil.
                    </div>

                <?php else: ?>

                    <div class="mb-3">

                        <label
                            for="empleado_id"
                            class="form-label portal-form-label"
                        >
                            Seleccione un empleado
                            <span class="portal-required">*</span>
                        </label>

                        <select
                            name="empleado_id"
                            id="empleado_id"
                            class="form-select portal-form-control
                                <?php $__errorArgs = ['empleado_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required
                        >
                            <option value="">
                                Seleccione un empleado disponible
                            </option>

                            <?php $__currentLoopData = $empleadosDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php
                                    $personaEmpleado = $empleado->persona;
                                ?>

                                <option
                                    value="<?php echo e($empleado->id); ?>"
                                    data-name="<?php echo e($personaEmpleado?->nombre_completo); ?>"
                                    data-employee-code="<?php echo e($empleado->codigo_empleado); ?>"
                                    data-document="<?php echo e($personaEmpleado?->numero_documento); ?>"
                                    data-email="<?php echo e($personaEmpleado?->correo_personal); ?>"
                                    data-phone="<?php echo e($personaEmpleado?->telefono_movil); ?>"
                                    data-photo="<?php echo e($personaEmpleado?->foto_perfil
                                        ? asset('storage/' . $personaEmpleado->foto_perfil)
                                        : ''); ?>"
                                    data-initials="<?php echo e($personaEmpleado?->iniciales); ?>"
                                    <?php if(
                                        (string) $empleadoIdActual
                                        === (string) $empleado->id
                                    ): echo 'selected'; endif; ?>
                                >
                                    <?php echo e($personaEmpleado?->nombre_completo); ?>

                                    — <?php echo e($empleado->codigo_empleado); ?>

                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                        <?php $__errorArgs = ['empleado_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="portal-form-help">
                            Solo aparecen empleados activos que aún no poseen
                            perfil docente.
                        </div>

                    </div>

                    <?php if($empleadosDisponibles->isEmpty()): ?>

                        <div class="portal-inline-notice portal-inline-notice-warning">

                            <i class="bi bi-exclamation-triangle"></i>

                            <div>
                                <strong>No hay empleados disponibles</strong>

                                <span>
                                    Todos los empleados activos ya poseen perfil
                                    docente o no existen empleados activos disponibles.
                                </span>
                            </div>

                            <a
                                href="<?php echo e(route('portal.empleados.create')); ?>"
                                class="btn portal-btn-secondary btn-sm"
                            >
                                Nuevo empleado
                            </a>

                        </div>

                    <?php endif; ?>

                    <div
                        class="portal-student-person-card"
                        id="selectedEmployeeCard"
                        <?php if(!$empleadoSeleccionado): ?> hidden <?php endif; ?>
                    >

                        <div class="portal-student-person-avatar">

                            <img
                                src="<?php echo e($empleadoSeleccionado?->persona?->foto_perfil
                                    ? asset(
                                        'storage/' .
                                        $empleadoSeleccionado->persona->foto_perfil
                                    )
                                    : ''); ?>"
                                alt="Fotografía del empleado"
                                id="selectedEmployeeImage"
                                <?php if(!$empleadoSeleccionado?->persona?->foto_perfil): ?> hidden <?php endif; ?>
                            >

                            <span
                                id="selectedEmployeeInitials"
                                <?php if($empleadoSeleccionado?->persona?->foto_perfil): ?> hidden <?php endif; ?>
                            >
                                <?php echo e($empleadoSeleccionado?->persona?->iniciales ?: 'DO'); ?>

                            </span>

                        </div>

                        <div class="portal-student-person-info">

                            <span class="portal-student-person-label">
                                Empleado seleccionado
                            </span>

                            <h3 id="selectedEmployeeName">
                                <?php echo e($empleadoSeleccionado?->persona?->nombre_completo); ?>

                            </h3>

                            <div class="portal-student-person-meta">

                                <span id="selectedEmployeeCodeWrapper">
                                    <i class="bi bi-upc-scan"></i>

                                    <span id="selectedEmployeeCode">
                                        <?php echo e($empleadoSeleccionado?->codigo_empleado); ?>

                                    </span>
                                </span>

                                <span id="selectedEmployeeDocumentWrapper">
                                    <i class="bi bi-credit-card-2-front"></i>

                                    <span id="selectedEmployeeDocument">
                                        <?php echo e($empleadoSeleccionado?->persona?->numero_documento); ?>

                                    </span>
                                </span>

                                <span id="selectedEmployeeEmailWrapper">
                                    <i class="bi bi-envelope"></i>

                                    <span id="selectedEmployeeEmail">
                                        <?php echo e($empleadoSeleccionado?->persona?->correo_personal); ?>

                                    </span>
                                </span>

                            </div>

                        </div>

                    </div>

                <?php endif; ?>

            </div>

        </section>

        
        <section class="portal-card portal-form-card">

            <div class="portal-form-section-header">

                <div class="portal-form-section-icon">
                    <i class="bi bi-easel"></i>
                </div>

                <div>
                    <h2>Información docente</h2>

                    <p>
                        Datos específicos de su función académica.
                    </p>
                </div>

            </div>

            <div class="portal-form-section-body">

                <div class="row g-3">

                    <div class="col-12">

                        <label
                            for="especialidad"
                            class="form-label portal-form-label"
                        >
                            Especialidad
                        </label>

                        <input
                            type="text"
                            name="especialidad"
                            id="especialidad"
                            value="<?php echo e(old(
                                'especialidad',
                                $docente?->especialidad
                            )); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['especialidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            maxlength="180"
                            placeholder="Ej. Enseñanza del idioma inglés"
                        >

                        <?php $__errorArgs = ['especialidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="fecha_inicio_docencia"
                            class="form-label portal-form-label"
                        >
                            Fecha de inicio de docencia
                            <span class="portal-required">*</span>
                        </label>

                        <input
                            type="date"
                            name="fecha_inicio_docencia"
                            id="fecha_inicio_docencia"
                            value="<?php echo e($fechaInicioActual); ?>"
                            max="<?php echo e(now()->format('Y-m-d')); ?>"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['fecha_inicio_docencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required
                        >

                        <?php $__errorArgs = ['fecha_inicio_docencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12 col-md-6">

                        <label
                            for="estado"
                            class="form-label portal-form-label"
                        >
                            Estado docente
                            <span class="portal-required">*</span>
                        </label>

                        <select
                            name="estado"
                            id="estado"
                            class="form-select portal-form-control
                                <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required
                        >
                            <option
                                value="activo"
                                <?php if($estadoActual === 'activo'): echo 'selected'; endif; ?>
                            >
                                Activo
                            </option>

                            <option
                                value="inactivo"
                                <?php if($estadoActual === 'inactivo'): echo 'selected'; endif; ?>
                            >
                                Inactivo
                            </option>
                        </select>

                        <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="col-12">

                        <label
                            for="observaciones"
                            class="form-label portal-form-label"
                        >
                            Observaciones
                        </label>

                        <textarea
                            name="observaciones"
                            id="observaciones"
                            rows="5"
                            maxlength="1000"
                            class="form-control portal-form-control
                                <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        ><?php echo e(old(
                            'observaciones',
                            $docente?->observaciones
                        )); ?></textarea>

                        <div class="portal-form-text-counter">

                            <span>
                                Información académica o administrativa opcional.
                            </span>

                            <span>
                                <strong id="observacionesCounter">0</strong>
                                / 1000
                            </span>

                        </div>

                        <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                </div>

            </div>

        </section>

    </div>

    
    <div class="col-12 col-xl-4">

        <div class="portal-form-sidebar">

            <section class="portal-card portal-form-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-upc-scan"></i>
                    </div>

                    <div>
                        <h2>Código docente</h2>

                        <p>
                            Identificador institucional del docente.
                        </p>
                    </div>

                </div>

                <div class="portal-form-section-body">

                    <?php if($modoEdicion): ?>

                        <div class="portal-student-code-panel">

                            <span>Código docente</span>

                            <strong>
                                <?php echo e($docente->codigo_docente); ?>

                            </strong>

                            <small>
                                Este código es único e inmutable.
                            </small>

                        </div>

                    <?php else: ?>

                        <div class="portal-student-code-panel portal-student-code-pending">

                            <span>Próximo código</span>

                            <strong>
                                Se generará automáticamente
                            </strong>

                            <small>
                                El correlativo será asignado al guardar.
                            </small>

                        </div>

                    <?php endif; ?>

                </div>

            </section>

            <section class="portal-card portal-form-card">

                <div class="portal-form-section-header">

                    <div class="portal-form-section-icon">
                        <i class="bi bi-info-circle"></i>
                    </div>

                    <div>
                        <h2>Información importante</h2>
                        <p>Reglas del perfil docente.</p>
                    </div>

                </div>

                <div class="portal-form-section-body">

                    <ul class="portal-form-guidelines">

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                Solo un empleado activo puede convertirse
                                en docente.
                            </span>
                        </li>

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                Cada empleado puede tener un único perfil
                                docente.
                            </span>
                        </li>

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                Los datos personales y laborales permanecen
                                en Personas y Empleados.
                            </span>
                        </li>

                        <li>
                            <i class="bi bi-check-circle"></i>

                            <span>
                                El código EDMA-DOC se genera automáticamente
                                y no puede modificarse.
                            </span>
                        </li>

                    </ul>

                </div>

            </section>

            <section class="portal-card portal-form-actions-card">

                <div class="portal-form-actions">

                    <button
                        type="submit"
                        class="btn portal-btn-primary w-100"
                        <?php if(
                            !$modoEdicion &&
                            $empleadosDisponibles->isEmpty()
                        ): echo 'disabled'; endif; ?>
                    >
                        <i class="bi bi-check2-circle"></i>

                        <?php echo e($modoEdicion
                            ? 'Guardar cambios'
                            : 'Crear perfil docente'); ?>

                    </button>

                    <a
                        href="<?php echo e($modoEdicion
                            ? route(
                                'portal.docentes.show',
                                $docente
                            )
                            : route('portal.docentes.index')); ?>"
                        class="btn portal-btn-secondary w-100"
                    >
                        Cancelar
                    </a>

                </div>

            </section>

        </div>

    </div>

</div>

<?php $__env->startPush('scripts'); ?>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const employeeSelect = document.getElementById(
            'empleado_id'
        );

        const employeeCard = document.getElementById(
            'selectedEmployeeCard'
        );

        const employeeImage = document.getElementById(
            'selectedEmployeeImage'
        );

        const employeeInitials = document.getElementById(
            'selectedEmployeeInitials'
        );

        const employeeName = document.getElementById(
            'selectedEmployeeName'
        );

        const employeeCode = document.getElementById(
            'selectedEmployeeCode'
        );

        const employeeCodeWrapper = document.getElementById(
            'selectedEmployeeCodeWrapper'
        );

        const employeeDocument = document.getElementById(
            'selectedEmployeeDocument'
        );

        const employeeDocumentWrapper = document.getElementById(
            'selectedEmployeeDocumentWrapper'
        );

        const employeeEmail = document.getElementById(
            'selectedEmployeeEmail'
        );

        const employeeEmailWrapper = document.getElementById(
            'selectedEmployeeEmailWrapper'
        );

        const observations = document.getElementById(
            'observaciones'
        );

        const observationsCounter = document.getElementById(
            'observacionesCounter'
        );

        const updateEmployeePreview = () => {
            if (!employeeSelect || !employeeCard) {
                return;
            }

            const option =
                employeeSelect.options[
                    employeeSelect.selectedIndex
                ];

            if (!option || option.value === '') {
                employeeCard.hidden = true;
                return;
            }

            const data = option.dataset;

            employeeCard.hidden = false;

            if (employeeName) {
                employeeName.textContent =
                    data.name || 'Empleado seleccionado';
            }

            if (
                employeeCode &&
                employeeCodeWrapper
            ) {
                employeeCode.textContent =
                    data.employeeCode || '';

                employeeCodeWrapper.hidden =
                    !data.employeeCode;
            }

            if (
                employeeDocument &&
                employeeDocumentWrapper
            ) {
                employeeDocument.textContent =
                    data.document || '';

                employeeDocumentWrapper.hidden =
                    !data.document;
            }

            if (
                employeeEmail &&
                employeeEmailWrapper
            ) {
                employeeEmail.textContent =
                    data.email || '';

                employeeEmailWrapper.hidden =
                    !data.email;
            }

            if (data.photo) {
                employeeImage.src = data.photo;
                employeeImage.hidden = false;
                employeeInitials.hidden = true;
            } else {
                employeeImage.src = '';
                employeeImage.hidden = true;

                employeeInitials.textContent =
                    data.initials || 'DO';

                employeeInitials.hidden = false;
            }
        };

        const updateObservationsCounter = () => {
            if (
                !observations ||
                !observationsCounter
            ) {
                return;
            }

            observationsCounter.textContent =
                observations.value.length;
        };

        employeeSelect?.addEventListener(
            'change',
            updateEmployeePreview
        );

        observations?.addEventListener(
            'input',
            updateObservationsCounter
        );

        updateEmployeePreview();
        updateObservationsCounter();
    });
</script>

<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\system-edma\resources\views/portal/docentes/partials/_form.blade.php ENDPATH**/ ?>