@extends('layouts.portal')

@section('title', 'Editar empleado | Portal EDMA')

@section('page-title', 'Editar empleado')

@section('page-header')

    <div class="portal-page-heading">

        <div>
            <span class="portal-page-eyebrow">
                Gestión de recursos humanos
            </span>

            <h1>Editar expediente laboral</h1>

            <p>
                Actualice la información laboral de
                {{ $empleado->persona->nombre_completo }}.
            </p>
        </div>

        <div class="portal-page-actions">

            <a
                href="{{ route('portal.empleados.show', $empleado) }}"
                class="btn portal-btn-secondary"
            >
                <i class="bi bi-arrow-left"></i>
                Volver al expediente
            </a>

        </div>

    </div>

@endsection

@section('content')

    <form
        action="{{ route('portal.empleados.update', $empleado) }}"
        method="POST"
        id="empleadoForm"
        novalidate
    >
        @csrf
        @method('PUT')

        @include('portal.empleados.partials._form', [
            'empleado' => $empleado,
            'modoEdicion' => true,
        ])

    </form>

@endsection